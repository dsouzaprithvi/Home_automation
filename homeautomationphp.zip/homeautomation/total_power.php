<?php
$conn = mysqli_connect("localhost","root","");
mysqli_select_db($conn,"home_automation");


$qry = "SELECT SUM(Bulb_Power_Value) bulbpower, SUM(Fan_Power_Value) fanpower,
		SUM(Relay_1_Power_Value) relay1power, SUM(Relay_2_Power_Value) relay2power FROM sensordata;";

$raw = mysqli_query($conn,$qry);

$count = mysqli_num_rows($raw);

if($count > 0){
	while($res = mysqli_fetch_array($raw)){
		$data[] = $res;
		}
}
else{
	$data[] = NULL;
}

echo json_encode($data);
?>