<?php
$conn = mysqli_connect("localhost","root","");
mysqli_select_db($conn,"home_automation");




$qry = "SELECT id,Bulb_Power_Value, reading_time FROM sensordata WHERE Bulb_Power_Value = '0'";

$raw = mysqli_query($conn,$qry);

$count = mysqli_num_rows($raw);

if($count > 0){
	while($res = mysqli_fetch_array($raw)){
		$data[] = $res;
		}
}
else{
	$data[] = NULL;
}

echo json_encode($data);
?>