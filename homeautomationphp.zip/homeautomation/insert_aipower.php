<?php
$conn = mysqli_connect("localhost","root","");
mysqli_select_db($conn,"home_automation");



$device1 = trim($_POST['device1']);
$device2 = trim($_POST['device2']);
$device3 = trim($_POST['device3']);
$device4 = trim($_POST['device4']);
$reading_time = trim($_POST['reading_time']);


$qry = "INSERT INTO `ai`(`id`, `device1`, `device2`, `device3`, `device4`, `reading_time`) VALUES ('','$device1','$device2','$device3','$device4',now())";

		$res = mysqli_query($conn, $qry);
		if($res == true)
			$response['message'] = "inserted";
		else
			$response['message'] = "failed";
		
echo json_encode($response);

?>