package com.example.home_automation.models;


//Model to fetch data from server or store on server
//Constructors to define objects and Getter and setter to get and set respective values


public class Status {


    String id, server, gsm;

    public Status(String id, String server, String gsm) {
        this.id = id;
        this.server = server;
        this.gsm = gsm;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getServer() {
        return server;
    }

    public void setServer(String server) {
        this.server = server;
    }

    public String getGsm() {
        return gsm;
    }

    public void setGsm(String gsm) {
        this.gsm = gsm;
    }
}
