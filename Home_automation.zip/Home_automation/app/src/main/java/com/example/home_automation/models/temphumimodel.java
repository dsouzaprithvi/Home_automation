package com.example.home_automation.models;


//Model to fetch data from server or store on server
//Constructors to define objects and Getter and setter to get and set respective values

public class temphumimodel {

    String id, temperature, humidity;

    public temphumimodel(String id, String temperature, String humidity) {
        this.id = id;
        this.temperature = temperature;
        this.humidity = humidity;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public String getHumidity() {
        return humidity;
    }

    public void setHumidity(String humidity) {
        this.humidity = humidity;
    }
}
