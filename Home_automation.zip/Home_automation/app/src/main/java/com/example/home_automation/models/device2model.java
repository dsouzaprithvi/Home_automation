package com.example.home_automation.models;

//Model to fetch data from server or store on server
//Constructors to define objects and Getter and setter to get and set respective values


public class device2model {

    String id, status, fan_speed, power, auto;

    String Fan_Power_Value, reading_time ;

    String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public device2model(String id, String status, String fan_speed, String power, String auto) {
        this.id = id;
        this.status = status;
        this.fan_speed = fan_speed;
        this.power = power;
        this.auto = auto;
    }

    public device2model(String id, String fan_Power_Value, String reading_time) {
        this.id = id;
        Fan_Power_Value = fan_Power_Value;
        this.reading_time = reading_time;
    }

    public String getFan_Power_Value() {
        return Fan_Power_Value;
    }

    public void setFan_Power_Value(String fan_Power_Value) {
        Fan_Power_Value = fan_Power_Value;
    }

    public String getReading_time() {
        return reading_time;
    }

    public void setReading_time(String reading_time) {
        this.reading_time = reading_time;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getFan_speed() {
        return fan_speed;
    }

    public void setFan_speed(String fan_speed) {
        this.fan_speed = fan_speed;
    }

    public String getPower() {
        return power;
    }

    public void setPower(String power) {
        this.power = power;
    }

    public String getAuto() {
        return auto;
    }

    public void setAuto(String auto) {
        this.auto = auto;
    }
}
