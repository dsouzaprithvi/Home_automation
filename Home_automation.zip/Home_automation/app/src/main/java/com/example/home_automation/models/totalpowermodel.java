package com.example.home_automation.models;

public class totalpowermodel {

    String bulbpower, fanpower, relay1power, relay2power;

    public totalpowermodel(String bulbpower, String fanpower, String relay1power, String relay2power) {
        this.bulbpower = bulbpower;
        this.fanpower = fanpower;
        this.relay1power = relay1power;
        this.relay2power = relay2power;
    }

    public String getBulbpower() {
        return bulbpower;
    }

    public void setBulbpower(String bulbpower) {
        this.bulbpower = bulbpower;
    }

    public String getFanpower() {
        return fanpower;
    }

    public void setFanpower(String fanpower) {
        this.fanpower = fanpower;
    }

    public String getRelay1power() {
        return relay1power;
    }

    public void setRelay1power(String relay1power) {
        this.relay1power = relay1power;
    }

    public String getRelay2power() {
        return relay2power;
    }

    public void setRelay2power(String relay2power) {
        this.relay2power = relay2power;
    }
}
