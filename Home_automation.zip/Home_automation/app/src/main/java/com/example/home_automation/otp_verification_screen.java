package com.example.home_automation;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class otp_verification_screen extends AppCompatActivity {

    TextView mobile_no;
    Button verify_otp;
    Dialog dialog;
    LinearLayout dialog_layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp_verification_screen);

        //hooks
        mobile_no = findViewById(R.id.textmobile);
        verify_otp = findViewById(R.id.buttonverifyotp);



        //get mobile number from previous activity
        mobile_no.setText(getIntent().getStringExtra("mobile_no"));

        //inflate view to display verified dialog
        View view = getLayoutInflater().inflate(R.layout.verified_dialog, null);
        //hook after layout is inflated
        dialog_layout = view.findViewById(R.id.dialog_layout);
        //set dialog theme
        dialog = new Dialog(this, R.style.Theme_Home_automation);
        dialog.setContentView(view);

        //onclick function for dialog



        //onclick function for button
        verify_otp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.show();
            }
        });

        dialog_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
                Intent intent = new Intent(otp_verification_screen.this, MainActivity.class);
                startActivity(intent);

            }
        });


    }
}