package com.example.home_automation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.marcinmoskala.arcseekbar.ArcSeekBar;
import com.marcinmoskala.arcseekbar.ProgressListener;

public class light_intensity_monitor extends AppCompatActivity {


    ArcSeekBar seekBar;
    TextView value;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_light_intensity_monitor);


        seekBar = findViewById(R.id.arc_seek_bar);
        value = findViewById(R.id.value);

        seekBar.setOnProgressChangedListener(new ProgressListener() {
            @Override
            public void invoke(int i) {
                Log.d("Value-->>>>>",""+i);
                String val = String.valueOf(i);
                value.setText(val);
            }
        });
    }
}