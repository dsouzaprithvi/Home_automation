package com.example.home_automation;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class otp_screen extends AppCompatActivity {

    Button otpverification;
    TextView mobile_number;

    com.hbb20.CountryCodePicker countrycode;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp_screen);


        otpverification = findViewById(R.id.otpverification);
        mobile_number = findViewById(R.id.input_mobile_number);
        countrycode = findViewById(R.id.ccp);

        otpverification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(otp_screen.this, otp_verification_screen.class);
                String mobile = countrycode.getSelectedCountryCodeWithPlus() + mobile_number.getText().toString();
                intent.putExtra("mobile_no", mobile);
                startActivity(intent);
            }
        });
    }
}