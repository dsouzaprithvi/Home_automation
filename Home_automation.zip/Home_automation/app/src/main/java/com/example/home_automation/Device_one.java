package com.example.home_automation;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.compose.ui.graphics.Color;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;

public class Device_one extends AppCompatActivity {

    SwitchCompat switch_button;
    ImageView light_bulb_image;
    Button auto;
    int i=0;
    SeekBar seekBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_one);


        switch_button = findViewById(R.id.switch_button);
        light_bulb_image = findViewById(R.id.light_bulb);
        auto = findViewById(R.id.auto);
        seekBar = findViewById(R.id.seekBar);


        switch_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(switch_button.isChecked()){
                    light_bulb_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_free_lightbulb_icon_11));
                }
                else{
                    light_bulb_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_free_lightbulb_icon_11_off));
                }
            }
        });

        auto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(i==0){
                    auto.setBackgroundColor(getResources().getColor(R.color.black));
                    i=1;
                }
                else{
                    auto.setBackgroundColor(getResources().getColor(R.color.teal_200));
                    i=0;
                }
            }
        });
    }
}