package com.example.home_automation;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.compose.ui.graphics.Color;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.home_automation.models.device1model;
import com.example.home_automation.models.temphumimodel;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Device_one extends AppCompatActivity {

    //Initializations

    SwitchCompat switch_button;
    ImageView light_bulb_image;
    Button auto;
    int i=0;
    SeekBar seekBar;
    TextView brightness_value;
    List<device1model> data;

    //Phone number to get sms from
    String phone = "+911234567890", currentTime , currentDate;
    int count = 10;
    int flag = 0;
    boolean server = true;


    ProgressDialog progressDialog;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_one);


        //hooks to get connect id from layout
        switch_button = findViewById(R.id.switch_button);
        light_bulb_image = findViewById(R.id.light_bulb);
        auto = findViewById(R.id.auto);
        seekBar = findViewById(R.id.seekBar);
        brightness_value = findViewById(R.id.brightness_value);

        progressDialog = new ProgressDialog(Device_one.this);
        progressDialog.setTitle("Loading Values");
        progressDialog.show();


        processdata();


        //Switch button functions
        switch_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //if server connection available then use server
                if (server) {
                    if(switch_button.isChecked()){
                        light_bulb_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_free_lightbulb_icon_11));
                        storedata("on", "100", "50", "off");
                        seekBar.setVisibility(View.VISIBLE);
                        seekBar.setProgress(100);
                    }
                    else{
                        light_bulb_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_free_lightbulb_icon_11_off));
                        storedata("off", "0", "50", "off");
                        seekBar.setProgress(0);
                    }
                } else {
                    //If server not available use GSM
                    progressDialog.show();
                    if(switch_button.isChecked()) {
                        light_bulb_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_free_lightbulb_icon_11));
                        //send sms to device in this format
                        String message = "bulb 75";
                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(phone, null, message, null, null);
                        flag = 0;
                        currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                        currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                        timerfunction();
                    } else {
                        light_bulb_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_free_lightbulb_icon_11_off));
                        //send sms to device in this format
                        String message = "bulb 0";
                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(phone, null, message, null, null);
                        flag = 0;
                        currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                        currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                        timerfunction();
                    }
                }
            }
        });

        //Function for AUTO button
        auto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String status;
                if (switch_button.isChecked()) {
                    status = "on";
                } else {
                    status = "off";
                }
                if (server) {
                    //If server available then ipdate values to server
                    if(auto.getText().toString().equals("Auto")){
                        auto.setBackgroundColor(getResources().getColor(R.color.black));
                        auto.setText("Maunal");
                        i=1;
                        switch_button.setVisibility(View.VISIBLE);
                        seekBar.setVisibility(View.VISIBLE);
                        brightness_value.setVisibility(View.VISIBLE);
                        storedata(status, brightness_value.getText().toString(), "50", "off");
                    }
                    else{
                        auto.setBackgroundColor(getResources().getColor(R.color.teal_200));
                        auto.setText("Auto");
                        switch_button.setVisibility(View.INVISIBLE);
                        seekBar.setVisibility(View.INVISIBLE);
                        brightness_value.setVisibility(View.INVISIBLE);
                        i=0;
                        storedata(status, brightness_value.getText().toString(), "50", "on");
                    }
                }else {
                    //IF server not available then update values using GSM
                    progressDialog.show();
                    if(auto.getText().toString().equals("Auto")) {
                        auto.setBackgroundColor(getResources().getColor(R.color.black));
                        auto.setText("Maunal");
                        i=1;
                        switch_button.setVisibility(View.VISIBLE);
                        String message = "bulb 0";
                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(phone, null, message, null, null);
                        flag = 0;
                        currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                        currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                        timerfunction();
                    } else {
                        auto.setBackgroundColor(getResources().getColor(R.color.teal_200));
                        auto.setText("Auto");
                        switch_button.setVisibility(View.INVISIBLE);
                        i=0;
                        String message = "bulb a";
                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(phone, null, message, null, null);
                        flag = 0;
                        currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                        currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                        timerfunction();

                    }
                }

            }
        });

        //Function for brightness bar in app
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                brightness_value.setText(""+i);

                if (i == 0){
                    light_bulb_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_free_lightbulb_icon_11_off));
                    switch_button.setChecked(false);
                } else {
                    light_bulb_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_free_lightbulb_icon_11));
                    switch_button.setChecked(true);
                }
                String status;
                if (switch_button.isChecked()) {
                    status = "on";
                } else {
                    status = "off";
                }
                storedata(status, ""+i, "50", data.get(0).getAuto());
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

//    @Override
//    public void onBackPressed() {
//        startActivity(new Intent(Device_one.this, MainActivity.class));
//        finish();
//    }


    // Load data from server function and update the layout accordingly
    private void processdata() {

        Call<List<device1model>> call = apicontroller
                .getInstance()
                .getapi()
                .getdevice1();

        call.enqueue(new Callback<List<device1model>>() {
            @Override
            public void onResponse(Call<List<device1model>> call, Response<List<device1model>> response) {
                progressDialog.dismiss();
                server = true;
                data = response.body();
                brightness_value.setText(data.get(0).getLight_intensity());
                int i = Integer.parseInt(data.get(0).getLight_intensity());
                seekBar.setProgress(i);

                if (data.get(0).getAuto().equals("on")) {
                    auto.setBackgroundColor(getResources().getColor(R.color.teal_200));
                    auto.setText("Auto");
                    switch_button.setVisibility(View.INVISIBLE);
                    seekBar.setVisibility(View.INVISIBLE);
                    brightness_value.setVisibility(View.INVISIBLE);
                    i=0;
                } else {
                    auto.setBackgroundColor(getResources().getColor(R.color.black));
                    auto.setText("Manual");
                    switch_button.setVisibility(View.VISIBLE);
                    seekBar.setVisibility(View.VISIBLE);
                    brightness_value.setVisibility(View.VISIBLE);
                    i=1;
                    String status = data.get(0).getStatus();
                    if (status.equals("on")){
                        switch_button.setChecked(true);
                        light_bulb_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_free_lightbulb_icon_11));
                        seekBar.setVisibility(View.VISIBLE);
                    } else {
                        switch_button.setChecked(false);
                        light_bulb_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_free_lightbulb_icon_11_off));
                    }
                }


            }

            @Override
            public void onFailure(Call<List<device1model>> call, Throwable t) {
                seekBar.setVisibility(View.INVISIBLE);
                brightness_value.setVisibility(View.INVISIBLE);
                server = false;
                String message = "device1";
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phone, null, message, null, null);
                flag = 0;
                currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                timerfunction();
            }

        });
    }

    //Store data on server function
    private void storedata(String status, String light_intensity, String power, String auto){
        Call<device1model> call3 = apicontroller
                .getInstance()
                .getapi()
                .getmessage1(status, light_intensity, power, auto);


        call3.enqueue(new Callback<device1model>() {
            @Override
            public void onResponse(Call<device1model> call, Response<device1model> response) {
                device1model mess = response.body();
                if (mess.getMessage().equals("inserted")){
                    Toast.makeText(getApplicationContext(), "sms inserted", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<device1model> call, Throwable t) {
                    Toast.makeText(getApplicationContext(), t.toString(), Toast.LENGTH_LONG).show();
                    Log.i("error------>", t.toString());
            }
        });
    }

    //Function to check sms in sms inbox
    private void status(){
        ContentResolver cResolver = getContentResolver();
        Cursor smsInboxCursor = cResolver.query(Uri.parse("content://sms/inbox"),
                null ,null, null, null);
        smsInboxCursor.moveToFirst();

        int indexBody = smsInboxCursor.getColumnIndex("body");
        int indexAddress = smsInboxCursor.getColumnIndex("address");
        int indexDate = smsInboxCursor.getColumnIndex("date");
        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        SimpleDateFormat tf = new SimpleDateFormat("HH:mm:ss");

        do {

            String body, sender, date, time;
            sender = smsInboxCursor.getString(indexAddress);
            body = smsInboxCursor.getString(indexBody).toString();
            date = df.format(smsInboxCursor.getLong(indexDate));
            time = tf.format(smsInboxCursor.getLong(indexDate));


            if (phone.equals(sender)){
                String[] smsbody = body.split("\n");
                if(smsbody[0].matches("DEVICE1") && currentDate.matches(date) && currentTime.compareTo(time)<0 ){
                    progressDialog.dismiss();
                    Log.i("STASTATS-.........>>>>",smsbody[0]);
                    flag = 1;
                    String[] buffer1 = smsbody[1].split(" ");
                    if (buffer1[2].equals("on")){
                        switch_button.setChecked(true);
                        light_bulb_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_free_lightbulb_icon_11));
                        seekBar.setVisibility(View.INVISIBLE);
                    } else {
                        switch_button.setChecked(false);
                        light_bulb_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_free_lightbulb_icon_11_off));
                        seekBar.setVisibility(View.INVISIBLE);
                    }


                    String[] buffer3 = smsbody[2].split(" ");
                    if ( buffer3[2].equals("on")) {
                        auto.setBackgroundColor(getResources().getColor(R.color.teal_200));
                        auto.setText("Auto");
                        switch_button.setVisibility(View.INVISIBLE);
                    }else {
                        auto.setBackgroundColor(getResources().getColor(R.color.black));
                        auto.setText("Maunal");
                        switch_button.setVisibility(View.VISIBLE);
                    }
                }

            }
        }while (smsInboxCursor.moveToNext());
    }

    //Timer function to check if the message is received within set time
    private void timerfunction() {
        long duration = TimeUnit.MINUTES.toMillis(1);
        new CountDownTimer(duration, 1000) {
            @Override
            public void onTick(long l) {
                String sDuration = String.format(Locale.ENGLISH, "%02d"
                        , TimeUnit.MILLISECONDS.toSeconds(l)
                        , TimeUnit.MILLISECONDS.toSeconds(l) -
                                TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(1)));
                String c = Integer.toString(count);
                Log.d("COUNT-------->", c);
                if (count == 0) {
                    count = 10;
                    status();
                }
                else{
                    count = count - 1;
                }
                if(flag == 1){
                    cancel();
                }

            }

            @Override
            public void onFinish() {
                progressDialog.dismiss();
            }
        }.start();


    }

}