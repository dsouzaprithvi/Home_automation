package com.example.home_automation.models;

public class aipowermodel {

    String id, device1, device2, device3, device4, reading_time;

    String message;

    public aipowermodel(String message) {
        this.message = message;
    }

    public aipowermodel(String id, String device1, String device2, String device3, String device4, String reading_time) {
        this.id = id;
        this.device1 = device1;
        this.device2 = device2;
        this.device3 = device3;
        this.device4 = device4;
        this.reading_time = reading_time;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDevice1() {
        return device1;
    }

    public void setDevice1(String device1) {
        this.device1 = device1;
    }

    public String getDevice2() {
        return device2;
    }

    public void setDevice2(String device2) {
        this.device2 = device2;
    }

    public String getDevice3() {
        return device3;
    }

    public void setDevice3(String device3) {
        this.device3 = device3;
    }

    public String getDevice4() {
        return device4;
    }

    public void setDevice4(String device4) {
        this.device4 = device4;
    }

    public String getReading_time() {
        return reading_time;
    }

    public void setReading_time(String reading_time) {
        this.reading_time = reading_time;
    }
}
