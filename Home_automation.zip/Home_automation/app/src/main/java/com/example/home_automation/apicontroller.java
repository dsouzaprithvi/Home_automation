package com.example.home_automation;




import android.content.SharedPreferences;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


//Retorfit api to connect to server


public class apicontroller {

    private static String url = "http://192.168.1.15/homeautomation/";
    private static apicontroller clientobject;
    private static Retrofit retrofit;


    apicontroller(){
        retrofit = new Retrofit.Builder()
                .baseUrl(url)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
    }

    public static  void changeurl (String newurl) {
        url = newurl ;
        retrofit = new Retrofit.Builder()
                .baseUrl(url)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
    }


    public static synchronized apicontroller getInstance(){
        if (clientobject == null){
            clientobject = new apicontroller();
        }
        return clientobject;
    }

    apiset getapi(){
        return retrofit.create(apiset.class);
    }


}
