package com.example.home_automation.models;

public class sensordatamodel {

    String message;

    public sensordatamodel(String message) {
        this.message = message;
    }

    int id;
    String TemperatureValue, HumidityValue,
            LightSensorValue,
            Relay_1_Power_Value,
            Relay_2_Power_Value,
            Bulb_Power_Value,
            Fan_Power_Value,
            reading_time;

    public sensordatamodel(int id, String temperatureValue,
                           String humidityValue,
                           String lightSensorValue,
                           String relay_1_Power_Value,
                           String relay_2_Power_Value,
                           String bulb_Power_Value,
                           String fan_Power_Value,
                           String reading_time) {
        this.id = id;
        TemperatureValue = temperatureValue;
        HumidityValue = humidityValue;
        LightSensorValue = lightSensorValue;
        Relay_1_Power_Value = relay_1_Power_Value;
        Relay_2_Power_Value = relay_2_Power_Value;
        Bulb_Power_Value = bulb_Power_Value;
        Fan_Power_Value = fan_Power_Value;
        this.reading_time = reading_time;


    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTemperatureValue() {
        return TemperatureValue;
    }

    public void setTemperatureValue(String temperatureValue) {
        TemperatureValue = temperatureValue;
    }

    public String getHumidityValue() {
        return HumidityValue;
    }

    public void setHumidityValue(String humidityValue) {
        HumidityValue = humidityValue;
    }

    public String getLightSensorValue() {
        return LightSensorValue;
    }

    public void setLightSensorValue(String lightSensorValue) {
        LightSensorValue = lightSensorValue;
    }

    public String getRelay_1_Power_Value() {
        return Relay_1_Power_Value;
    }

    public void setRelay_1_Power_Value(String relay_1_Power_Value) {
        Relay_1_Power_Value = relay_1_Power_Value;
    }

    public String getRelay_2_Power_Value() {
        return Relay_2_Power_Value;
    }

    public void setRelay_2_Power_Value(String relay_2_Power_Value) {
        Relay_2_Power_Value = relay_2_Power_Value;
    }

    public String getBulb_Power_Value() {
        return Bulb_Power_Value;
    }

    public void setBulb_Power_Value(String bulb_Power_Value) {
        Bulb_Power_Value = bulb_Power_Value;
    }

    public String getFan_Power_Value() {
        return Fan_Power_Value;
    }

    public void setFan_Power_Value(String fan_Power_Value) {
        Fan_Power_Value = fan_Power_Value;
    }

    public String getReading_time() {
        return reading_time;
    }

    public void setReading_time(String reading_time) {
        this.reading_time = reading_time;
    }


}
