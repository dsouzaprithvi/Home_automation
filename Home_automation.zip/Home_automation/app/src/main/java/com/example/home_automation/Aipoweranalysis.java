package com.example.home_automation;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.example.home_automation.models.aipowermodel;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Aipoweranalysis extends AppCompatActivity {

    TextView device1power, device2power, device3power, device4power,
            device1aipower, device2aipower, device3aipower, device4aipower;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aipoweranalysis);

        device1power = findViewById(R.id.device1power);
        device2power = findViewById(R.id.device2power);
        device3power = findViewById(R.id.device3power);
        device4power = findViewById(R.id.device4power);

        device1aipower = findViewById(R.id.device1aipower);
        device2aipower = findViewById(R.id.device2aipower);
        device3aipower = findViewById(R.id.device3aipower);
        device4aipower = findViewById(R.id.device4aipower);


        processaipower();
        processwithoutaipower();


    }

    private void processaipower() {

        Call<List<aipowermodel>> call = apicontroller
                .getInstance()
                .getapi()
                .getaipower();

        call.enqueue(new Callback<List<aipowermodel>>() {
            @Override
            public void onResponse(Call<List<aipowermodel>> call, Response<List<aipowermodel>> response) {
                List<aipowermodel> data = response.body();
                try {
                    device1aipower.setText(data.get(0).getDevice1()+ " kWh");
                    device2aipower.setText(data.get(0).getDevice2()+ " kWh");
                    device3aipower.setText(data.get(0).getDevice3()+ " kWh");
                    device4aipower.setText(data.get(0).getDevice4()+ " kWh");
                } catch (NullPointerException e) {
                    Toast.makeText(Aipoweranalysis.this, "No Entries in server", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<aipowermodel>> call, Throwable t) {

            }
        });
    }

    private void processwithoutaipower() {

        Call<List<aipowermodel>> call = apicontroller
                .getInstance()
                .getapi()
                .getwithoutaipower();

        call.enqueue(new Callback<List<aipowermodel>>() {
            @Override
            public void onResponse(Call<List<aipowermodel>> call, Response<List<aipowermodel>> response) {
                List<aipowermodel> data = response.body();
                try {
                    device1power.setText(data.get(0).getDevice1()+ " kWh");
                    device2power.setText(data.get(0).getDevice2()+ " kWh");
                    device3power.setText(data.get(0).getDevice3()+ " kWh");
                    device4power.setText(data.get(0).getDevice4()+ " kWh");
                } catch (NullPointerException e) {
                    Toast.makeText(Aipoweranalysis.this, "No Entries in server", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<aipowermodel>> call, Throwable t) {

            }
        });
    }
    @Override
    public void onBackPressed() {
        startActivity(new Intent(Aipoweranalysis.this, MainActivity.class));
        finish();
    }
}