package com.example.home_automation;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    CardView ai,motion, device_1, device_2, device_3, device_4;
    RelativeLayout relativeLayoutai;
    TextView date;
    String currentDate;
    int aiflag = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        ai = findViewById(R.id.card_ai);
        device_1 = findViewById(R.id.card_device1);
        device_2 = findViewById(R.id.card_device2);
        date = findViewById(R.id.date);
        relativeLayoutai = findViewById(R.id.relativeLayoutai);

        currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        date.setText(currentDate);




        ai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (aiflag == 0){
                    relativeLayoutai.setBackground(getResources().getDrawable(R.drawable.boxoff));
                    aiflag = 1;
                }else {
                    relativeLayoutai.setBackground(getResources().getDrawable(R.drawable.box));
                    aiflag = 0;
                }

            }
        });

//        device_1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(MainActivity.this, Device_one.class));
//            }
//        });

//        device_2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(MainActivity.this, Device_two.class));
//            }
//        });
    }
}