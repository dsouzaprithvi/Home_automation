package com.example.home_automation;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.speech.RecognizerIntent;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.airbnb.lottie.LottieAnimationView;
import com.example.home_automation.models.Status;
import com.example.home_automation.models.aipowermodel;
import com.example.home_automation.models.device1model;
import com.example.home_automation.models.device2model;
import com.example.home_automation.models.device3model;
import com.example.home_automation.models.device4model;
import com.example.home_automation.models.deviceupdatemodel;
import com.example.home_automation.models.sensordatamodel;
import com.example.home_automation.models.totalpowermodel;
import com.google.firebase.auth.FirebaseAuth;

import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    CardView ai,motion, device_1, device_2, device_3, device_4;
    boolean server = true;
    RelativeLayout relativeLayoutai, relativeLayoutmotion;
    TextView date, temperature, humidity, status, powerusage, lightintensity;
    ImageView status_icon;
    Button sendsms;
    String currentDate;
    TextView device1power, device2power, device3power, device4power,
            device1powerconsumption,device2powerconsumption ,
            device3powerconsumption, device4powerconsumption;
    LottieAnimationView voiceanimation;
    int aiflag = 3 ;
    String phone , currentTime;
    int count = 10;
    int flag = 0;
    Float bulb_power, fan_power, device3_power, device4_power;
    CountDownTimer powertimer;

    private static final int REQUEST_CODE_SPEECH_INPUT = 1;

    ProgressDialog progressDialog;

    FirebaseAuth auth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        SharedPreferences sharedPreferences = getSharedPreferences("phonenumber", 0);
        phone = sharedPreferences.getString("Device_number", String.valueOf(0));




        ai = findViewById(R.id.card_ai);
        motion = findViewById(R.id.card_motion);
        lightintensity = findViewById(R.id.lightIntensity);
        device_1 = findViewById(R.id.card_device1);
        device_2 = findViewById(R.id.card_device2);
        device_3 = findViewById(R.id.card_device3);
        device_4 = findViewById(R.id.card_device4);
        device1power = findViewById(R.id.device1power);
        device2power = findViewById(R.id.device2power);
        device3power = findViewById(R.id.device3power);
        device4power = findViewById(R.id.device4power);
        voiceanimation = findViewById(R.id.voice_animation);
        sendsms = findViewById(R.id.send_sms);
        date = findViewById(R.id.date);
        relativeLayoutai = findViewById(R.id.relativeLayoutai);
        relativeLayoutmotion = findViewById(R.id.relativeLayoutmotion);
        temperature = findViewById(R.id.temperature);
        humidity = findViewById(R.id.humidity);
        status = findViewById(R.id.status);
        status_icon = findViewById(R.id.status_icon);
        powerusage = findViewById(R.id.powerUsage);
//        device1powerconsumption = findViewById(R.id.device1powerconsumption);
//        device2powerconsumption = findViewById(R.id.device2powerconsumption);
//        device3powerconsumption = findViewById(R.id.device3powerconsumption);
//        device4powerconsumption = findViewById(R.id.device4powerconsumption);



        DecimalFormat decimalFormat = new DecimalFormat("#.##");


        progressDialog = new ProgressDialog(MainActivity.this);
        progressDialog.setTitle("Loading Values");
        progressDialog.show();




        auth = FirebaseAuth.getInstance();

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);


        currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        date.setText(currentDate);

        processstatus();





        ai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (aiflag == 1){
                    relativeLayoutai.setBackground(getResources().getDrawable(R.drawable.boxoff));
                    aiflag = 0;
                    storeoutputsdata("BULB_A", "0");
                    storeoutputsdata("FAN_A", "0");
                    motion.setEnabled(true);
                    device_1.setEnabled(true);
                    device_2.setEnabled(true);
                }else {
                    relativeLayoutai.setBackground(getResources().getDrawable(R.drawable.box));
                    motion.setEnabled(false);
                    device_1.setEnabled(false);
                    device_2.setEnabled(false);
                    storeoutputsdata("BULB_A", "1");
                    storeoutputsdata("FAN_A", "1");
                    aiflag = 1;
                }
            }
        });

        motion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent
                        = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,
                        Locale.getDefault());
                intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to text");
                try {
                    startActivityForResult(intent, REQUEST_CODE_SPEECH_INPUT);
                } catch (Exception e) {
                    Toast
                            .makeText(MainActivity.this, " " + e.getMessage(),
                                    Toast.LENGTH_SHORT)
                            .show();
                }
            }
        });

        device_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, Device_one.class));
                finish();
                if (server){
                    powertimer.cancel();
                }
            }
        });


        device_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, Device_two.class));
                finish();
                if (server){
                    powertimer.cancel();
                }
            }
        });

        device_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, Device_three.class));
                finish();
                if (server){
                    powertimer.cancel();
                }

            }
        });

        device_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, Device_four.class));
                finish();
                if (server){
                    powertimer.cancel();
                }
            }
        });

        sendsms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                timerfunction();
                sendsms.setVisibility(View.INVISIBLE);
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);

        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement

        if (id == R.id.logout) {
            if (server) {
                powertimer.cancel();
            }

            auth.signOut();
            Intent intent = new Intent(MainActivity.this, splash_screen.class);
            startActivity(intent);
            finish();
            return true;
        }

        if (id == R.id.editdevice) {

            Intent intent = new Intent(MainActivity.this,Editphonenumber.class);
            startActivity(intent);
            return true;
        }

        if (id == R.id.aipoweranalysis) {
            if (server) {
                powertimer.cancel();
            }

            Intent intent = new Intent(MainActivity.this,Aipoweranalysis.class);
            startActivity(intent);
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_SPEECH_INPUT) {
            if (resultCode == RESULT_OK && data != null) {
                ArrayList<String> result = data.getStringArrayListExtra(
                        RecognizerIntent.EXTRA_RESULTS);
//              to get text data from speech and run respective functions
                switch (Objects.requireNonNull(result).get(0)) {

                    case "fan of" :

                    case "fan off" :
                        storeoutputsdata("FAN_M", "0");
                        break;

                    case "fan on" :
                        storeoutputsdata("FAN_M", "75");
                        break;

                    case "bulb on" :
                        storeoutputsdata("BULB_M", "75");
                        break;

                    case "bulb of" :

                    case "bulb off" :
                        storeoutputsdata("BULB_M", "0");
                        break;

                    case "device 3 on" :
                        storeoutputsdata("Relay_1", "1");
                        break;

                    case "device 3 of" :

                    case "device 3 off" :
                        storeoutputsdata("Relay_1", "0");
                        break;

                    case "device for on" :

                    case "device 4 on" :
                        storeoutputsdata("Relay_2", "1");
                        break;

                    case "device for of" :

                    case "device for off" :

                    case "device 4 of" :

                    case "device 4 off" :
                        storeoutputsdata("Relay_2", "0");
                        break;

                    default:
                        Toast.makeText(MainActivity.this, "Command does not match\n Instead ask DEVICE 3 ON/OFF or BULB ON/OFF",
                        Toast.LENGTH_SHORT).show();
                }

            }
        }
    }

    private void update() {


        long currenttime = System.currentTimeMillis();
        if (aiflag == 1) {
            date.setText(currentDate);
            storepowerai(device1power.getText().toString(), device2power.getText().toString()
                    , device3power.getText().toString(), device4power.getText().toString(), currenttime);
        } else {
            storepowerwithoutai(device1power.getText().toString(), device2power.getText().toString()
                    , device3power.getText().toString(), device4power.getText().toString(), currenttime);

        }

    }

    private  void processsensordata() {
        Call<List<sensordatamodel>> callsensordata = apicontroller
                .getInstance()
                .getapi()
                .getsensordata();

        callsensordata.enqueue(new Callback<List<sensordatamodel>>() {
            @Override
            public void onResponse(Call<List<sensordatamodel>> call, Response<List<sensordatamodel>> response) {
                List<sensordatamodel> data = response.body();
                try {
                    temperature.setText(data.get(0).getTemperatureValue()+" \u2103");
                    humidity.setText(data.get(0).getHumidityValue()+" %");
                    lightintensity.setText(data.get(0).getLightSensorValue());
                    processpowerdata();
                    processdatabulb_a("BULB_A");

                } catch (NullPointerException nullPointerException) {
                    Toast.makeText(MainActivity.this, "No Entries in server", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<sensordatamodel>> call, Throwable t) {
                Log.i("Bulbpowervlue --->",t.getMessage());

            }
        });
    }

    private void processdatabulb_a(String name) {
        Call<List<deviceupdatemodel>> call = apicontroller
                .getInstance()
                .getapi()
                .getdeviceinfo(name);

        call.enqueue(new Callback<List<deviceupdatemodel>>() {
            @Override
            public void onResponse(Call<List<deviceupdatemodel>> call, Response<List<deviceupdatemodel>> response) {
                List<deviceupdatemodel> data = response.body();
                if (data.get(0).getState().equals("1")) {
                    processdatafan_a("FAN_A");
                } else {
                    aiflag = 0;
                }
            }

            @Override
            public void onFailure(Call<List<deviceupdatemodel>> call, Throwable t) {
                Log.i("Device 1 ---->>>>>>>>>>", t.getMessage());
            }
        });
    }

    private void processdatafan_a(String name) {
        Call<List<deviceupdatemodel>> call = apicontroller
                .getInstance()
                .getapi()
                .getdeviceinfo(name);

        call.enqueue(new Callback<List<deviceupdatemodel>>() {
            @Override
            public void onResponse(Call<List<deviceupdatemodel>> call, Response<List<deviceupdatemodel>> response) {
                List<deviceupdatemodel> data = response.body();
                if (data.get(0).getState().equals("1")) {
                    aiflag = 1;
                    relativeLayoutai.setBackground(getResources().getDrawable(R.drawable.box));
                } else {
                    aiflag = 0;
                }
            }

            @Override
            public void onFailure(Call<List<deviceupdatemodel>> call, Throwable t) {
                Log.i("Device 1 ---->>>>>>>>>>", t.getMessage());
            }
        });
    }


    private void processpowerdata() {

        Call<List<totalpowermodel>> call = apicontroller
                .getInstance()
                .getapi()
                .gettotalpower();

        call.enqueue(new Callback<List<totalpowermodel>>() {
            @Override
            public void onResponse(Call<List<totalpowermodel>> call, Response<List<totalpowermodel>> response) {
                DecimalFormat df = new DecimalFormat("#.##");
                List<totalpowermodel> data = response.body();
                bulb_power = Float.valueOf(df.format(Float.valueOf(data.get(0).getBulbpower())));
                fan_power = Float.valueOf(df.format(Float.valueOf(data.get(0).getFanpower())));
                device3_power = Float.valueOf(df.format(Float.valueOf(data.get(0).getRelay1power())));
                device4_power = Float.valueOf(df.format(Float.valueOf(data.get(0).getRelay2power())));

                device1power.setText(String.valueOf(bulb_power));
                device2power.setText(String.valueOf(fan_power));
                device3power.setText(String.valueOf(device3_power));
                device4power.setText(String.valueOf(device4_power));
                String total_power = String.valueOf(df.format(bulb_power + fan_power + device3_power + device4_power));
                powerusage.setText(total_power+ " kWh");
                update();
//                processzeropowerdata1();
            }

            @Override
            public void onFailure(Call<List<totalpowermodel>> call, Throwable t) {

            }
        });
    }

    private void processzeropowerdata1() {

        Call<List<device1model>> call = apicontroller
                .getInstance()
                .getapi()
                .getzerovalues1();

        call.enqueue(new Callback<List<device1model>>() {
            @Override
            public void onResponse(Call<List<device1model>> call, Response<List<device1model>> response) {

                Timestamp datetime1;
                Timestamp datetime2;
                float hours = 0;
                int id1, id2;
                List<device1model> data = response.body();
                int size = data.size();
                for ( int i = 1 ; i < size ; i++) {
                    id1 = Integer.parseInt(data.get(i - 1).getId());
                    id2 = Integer.parseInt(data.get(i).getId());
                    if ((id2 - id1) > 1) {
                        datetime1 = Timestamp.valueOf(data.get(i - 1).getReading_time());
                        datetime2 = Timestamp.valueOf(data.get(i).getReading_time());

                        long millis = datetime2.getTime() - datetime1.getTime();
                        float seconds = (float) millis / 1000;
                        hours =  seconds / 3600;

                    }
                }
                bulb_power = bulb_power/1000;
                hours = hours * bulb_power;
                device1powerconsumption.setText(String.valueOf((int)hours));
                Log.i("Time value ---->>>", String.valueOf(hours));
                processzeropowerdata2();
            }

            @Override
            public void onFailure(Call<List<device1model>> call, Throwable t) {
            }
        });
    }

    private void processzeropowerdata2() {

        Call<List<device2model>> call = apicontroller
                .getInstance()
                .getapi()
                .getzerovalues2();

       call.enqueue(new Callback<List<device2model>>() {
           @Override
           public void onResponse(Call<List<device2model>> call, Response<List<device2model>> response) {

               Timestamp datetime1;
               Timestamp datetime2;
               float hours = 0;
               int id1, id2;
               List<device2model> data = response.body();
               int size = data.size();
               for ( int i = 1 ; i < size ; i++) {
                   id1 = Integer.parseInt(data.get(i - 1).getId());
                   id2 = Integer.parseInt(data.get(i).getId());
                   if ((id2 - id1) > 1) {
                       datetime1 = Timestamp.valueOf(data.get(i - 1).getReading_time());
                       datetime2 = Timestamp.valueOf(data.get(i).getReading_time());

                       long millis = datetime2.getTime() - datetime1.getTime();
                       float seconds = (float) millis / 1000;
                       hours =  seconds / 3600;

                   }
               }
               Log.i("FAn_pwwrw-->>>",String.valueOf(hours) );
               fan_power = fan_power/1000;

               hours = hours * fan_power;
               device2powerconsumption.setText(String.valueOf((int)hours));
               processzeropowerdata3();


           }

           @Override
           public void onFailure(Call<List<device2model>> call, Throwable t) {

           }
       });
    }

    private void processzeropowerdata3() {

        Call<List<device3model>> call = apicontroller
                .getInstance()
                .getapi()
                .getzerovalues3();

        call.enqueue(new Callback<List<device3model>>() {
            @Override
            public void onResponse(Call<List<device3model>> call, Response<List<device3model>> response) {
                Timestamp datetime1;
                Timestamp datetime2;
                float hours = 0;
                int id1, id2;
                List<device3model> data = response.body();
                int size = data.size();
                for ( int i = 1 ; i < size ; i++) {
                    id1 = Integer.parseInt(data.get(i - 1).getId());
                    id2 = Integer.parseInt(data.get(i).getId());
                    if ((id2 - id1) > 1) {
                        datetime1 = Timestamp.valueOf(data.get(i - 1).getReading_time());
                        datetime2 = Timestamp.valueOf(data.get(i).getReading_time());

                        long millis = datetime2.getTime() - datetime1.getTime();
                        float seconds = (float) millis / 1000;
                        hours =  seconds / 3600;

                    }
                }
                device3_power = device3_power/1000;
                hours = hours * device3_power;
                device3powerconsumption.setText(String.valueOf((int)hours));
                processzeropowerdata4();
            }

            @Override
            public void onFailure(Call<List<device3model>> call, Throwable t) {

            }
        });
    }

    private void processzeropowerdata4() {

        Call<List<device4model>> call = apicontroller
                .getInstance()
                .getapi()
                .getzerovalues4();

        call.enqueue(new Callback<List<device4model>>() {
            @Override
            public void onResponse(Call<List<device4model>> call, Response<List<device4model>> response) {
                Timestamp datetime1;
                Timestamp datetime2;
                float hours = 0;
                int id1, id2;
                List<device4model> data = response.body();
                int size = data.size();
                for ( int i = 1 ; i < size ; i++) {
                    id1 = Integer.parseInt(data.get(i - 1).getId());
                    id2 = Integer.parseInt(data.get(i).getId());
                    if ((id2 - id1) > 1) {
                        datetime1 = Timestamp.valueOf(data.get(i - 1).getReading_time());
                        datetime2 = Timestamp.valueOf(data.get(i).getReading_time());

                        long millis = datetime2.getTime() - datetime1.getTime();
                        float seconds = (float) millis / 1000;
                        hours =  seconds / 3600;

                    }
                }
                device4_power = device4_power/1000;
                hours = hours * device4_power;
                device4powerconsumption.setText(String.valueOf((int)hours));
                update();
            }

            @Override
            public void onFailure(Call<List<device4model>> call, Throwable t) {

            }
        });
    }



//    private void processpowerdata() {
//        Call<List<sensordatamodel>> call= apicontroller
//                .getInstance()
//                .getapi()
//                .gettotalbulbpower();
//
//        call.enqueue(new Callback<List<sensordatamodel>>() {
//            @Override
//            public void onResponse(Call<List<sensordatamodel>> call, Response<List<sensordatamodel>> response) {
//                List<sensordatamodel> data = response.body();
//                bulb_power = Float.valueOf(data.get(0).getMessage());
//                Log.i("Bulbpower------->", String.valueOf(bulb_power));
//            }
//
//            @Override
//            public void onFailure(Call<List<sensordatamodel>> call, Throwable t) {
//                Log.i("Bulbpower------->", t.getMessage());
//            }
//        });
//
//        Call<List<sensordatamodel>> call1= apicontroller
//                .getInstance()
//                .getapi()
//                .gettotalfanpower();
//
//        call1.enqueue(new Callback<List<sensordatamodel>>() {
//            @Override
//            public void onResponse(Call<List<sensordatamodel>> call1, Response<List<sensordatamodel>> response) {
//                List<sensordatamodel> data = response.body();
//                fan_power = Float.valueOf(data.get(0).getMessage());
//                Log.i("Bulbpower------->", String.valueOf(fan_power));
//            }
//
//            @Override
//            public void onFailure(Call<List<sensordatamodel>> call1, Throwable t) {
//                Log.i("Bulbpower------->", t.getMessage());
//            }
//        });
//
//        Call<List<sensordatamodel>> call2= apicontroller
//                .getInstance()
//                .getapi()
//                .gettotalrelay1power();
//
//        call2.enqueue(new Callback<List<sensordatamodel>>() {
//            @Override
//            public void onResponse(Call<List<sensordatamodel>> call, Response<List<sensordatamodel>> response) {
//                List<sensordatamodel> data = response.body();
//                device3_power = Float.valueOf(data.get(0).getMessage());
//                Log.i("Bulbpower------->", String.valueOf(device3_power));
//            }
//
//            @Override
//            public void onFailure(Call<List<sensordatamodel>> call, Throwable t) {
//                Log.i("Bulbpower------->", t.getMessage());
//            }
//        });
//
//        Call<List<sensordatamodel>> call3= apicontroller
//                .getInstance()
//                .getapi()
//                .gettotalrelay2power();
//
//        call3.enqueue(new Callback<List<sensordatamodel>>() {
//            @Override
//            public void onResponse(Call<List<sensordatamodel>> call, Response<List<sensordatamodel>> response) {
//                List<sensordatamodel> data = response.body();
//                device4_power = Float.valueOf(data.get(0).getMessage());
//                Log.i("Bulbpower------->", String.valueOf(device4_power));
//            }
//
//            @Override
//            public void onFailure(Call<List<sensordatamodel>> call, Throwable t) {
//                Log.i("Bulbpower------->", t.getMessage());
//            }
//        });
//
//    }

    private void processstatus() {

        Call<List<Status>> callstatus = apicontroller
                .getInstance()
                .getapi()
                .getstatus();


        callstatus.enqueue(new Callback<List<Status>>() {
            @Override
            public void onResponse(Call<List<Status>> call, Response<List<Status>> response) {
                server = true;
                progressDialog.dismiss();
                sendsms.setVisibility(View.INVISIBLE);
                List<Status> data = response.body();
                String mode = data.get(0).getServer();
                if (mode.equals("on")) {
                    status.setText("CONNECTED TO SERVER");
                    status_icon.setImageDrawable(getResources().getDrawable(R.drawable.ic_wifi));
                    processsensordata();
                    timerfunctionpower();

                }else {
                    status.setText("CONNECTED TO GSM");
                    status_icon.setImageDrawable(getResources().getDrawable(R.drawable.ic_signal));
                }
                Log.i("Status----->", data.get(0).getServer());
            }

            @Override
            public void onFailure(Call<List<Status>> call, Throwable t) {
                progressDialog.dismiss();
                ai.setEnabled(false);
                motion.setEnabled(false);
                status.setText("CONNECTED TO GSM");
                status_icon.setImageDrawable(getResources().getDrawable(R.drawable.ic_signal));
                String message = "status";
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phone, null, message, null, null);
                server = false;
                flag = 0;
                currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
//                timerfunction();
            }
        });
    }

    private void storeoutputsdata (String name, String state) {

        Call<deviceupdatemodel> call = apicontroller
                .getInstance()
                .getapi()
                .getmessageupdate(name, state);

        call.enqueue(new Callback<deviceupdatemodel>() {
            @Override
            public void onResponse(Call<deviceupdatemodel> call, Response<deviceupdatemodel> response) {
                deviceupdatemodel mess = response.body();
                if (mess.getMessage().equals("inserted")){
                    Toast.makeText(getApplicationContext(), "sms inserted", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<deviceupdatemodel> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.toString(), Toast.LENGTH_LONG).show();
                Log.i("error------>", t.toString());
            }
        });
    }

    private void storepowerai (String device1, String device2, String device3, String device4, long reading_time) {

        Call<aipowermodel> call = apicontroller
                .getInstance()
                .getapi()
                .insertvalues(device1, device2, device3, device4, reading_time);

        call.enqueue(new Callback<aipowermodel>() {
            @Override
            public void onResponse(Call<aipowermodel> call, Response<aipowermodel> response) {
                aipowermodel message = response.body();
                Log.i("Power data uploaded--->", message.getMessage());
            }

            @Override
            public void onFailure(Call<aipowermodel> call, Throwable t) {

            }
        });


    }

    private void storepowerwithoutai (String device1, String device2, String device3, String device4, long reading_time) {

        Call<aipowermodel> call = apicontroller
                .getInstance()
                .getapi()
                .insertvalues1(device1, device2, device3, device4, reading_time);

        call.enqueue(new Callback<aipowermodel>() {
            @Override
            public void onResponse(Call<aipowermodel> call, Response<aipowermodel> response) {
                aipowermodel message = response.body();
                Log.i("Power data uploaded--->", message.getMessage());
            }

            @Override
            public void onFailure(Call<aipowermodel> call, Throwable t) {

            }
        });
    }

    private void status(){
        ContentResolver cResolver = getContentResolver();
        Cursor smsInboxCursor = cResolver.query(Uri.parse("content://sms/inbox"),
                null ,null, null, null);
        smsInboxCursor.moveToFirst();

        int indexBody = smsInboxCursor.getColumnIndex("body");
        int indexAddress = smsInboxCursor.getColumnIndex("address");
        int indexDate = smsInboxCursor.getColumnIndex("date");
        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        SimpleDateFormat tf = new SimpleDateFormat("HH:mm:ss");

        do {

            String body, sender, date, time;
            sender = smsInboxCursor.getString(indexAddress);
            body = smsInboxCursor.getString(indexBody).toString();
            date = df.format(smsInboxCursor.getLong(indexDate));
            time = tf.format(smsInboxCursor.getLong(indexDate));


            if (phone.equals(sender)){
                String[] smsbody = body.split("\n");
                if(smsbody[0].matches("STATUS") && currentDate.matches(date) && currentTime.compareTo(time)<0 ){
                    progressDialog.dismiss();
                    sendsms.setVisibility(View.VISIBLE);
//                    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                    Log.i("STASTATS-.........>>>>",smsbody[0]);
                    flag = 1;
                    String[] buffer1 = smsbody[1].split(" ");
                    temperature.setText(buffer1[2]+" \u2103");
                    String[] buffer2 = smsbody[2].split(" ");
                    humidity.setText(buffer2[2]+" %");
                    String[] buffer3 = smsbody[3].split(" ");
                    device1power.setText(buffer3[2]);
                    String[] buffer4 = smsbody[4].split(" ");
                    device2power.setText(buffer4[2]);
                    String[] buffer5 = smsbody[5].split(" ");
                    device3power.setText(buffer5[2]);
                    String[] buffer6 = smsbody[6].split(" ");
                    device4power.setText(buffer6[2]);
//                    String[] buffer7 = smsbody[7].split(" ");
                    Float power1 = Float.valueOf(device1power.getText().toString());
                    Float power2 = Float.valueOf(device2power.getText().toString());
                    Float power3 = Float.valueOf(device3power.getText().toString());
                    Float power4 = Float.valueOf(device4power.getText().toString());
                    Float total = power1 + power2 + power3 + power4;
                    String total_power = String.valueOf(total);
                    powerusage.setText(total_power+ " W");


                }

            }
        }while (smsInboxCursor.moveToNext());
    }

    private void timerfunction() {
        progressDialog.show();
        sendsms.setVisibility(View.INVISIBLE);
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        sendsms.setVisibility(View.INVISIBLE);
        long duration = TimeUnit.MINUTES.toMillis(1);
        new CountDownTimer(duration, 1000) {
            @Override
            public void onTick(long l) {
                String sDuration = String.format(Locale.ENGLISH, "%02d"
                        , TimeUnit.MILLISECONDS.toSeconds(l)
                        , TimeUnit.MILLISECONDS.toSeconds(l) -
                                TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(1)));
                String c = Integer.toString(count);
                Log.d("COUNT-------->", c);
                if (count == 0) {
                    count = 10;
                    status();
                }
                else{
                    count = count - 1;
                }
                if(flag == 1){
                    cancel();
                }

            }

            @Override
            public void onFinish() {
                progressDialog.dismiss();
                sendsms.setVisibility(View.VISIBLE);
//                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
            }
        }.start();
    }

    private void timerfunctionpower() {
        progressDialog.dismiss();
        sendsms.setVisibility(View.INVISIBLE);
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        sendsms.setVisibility(View.INVISIBLE);
        long duration = TimeUnit.MINUTES.toMillis(1);
        powertimer = new CountDownTimer(duration, 1000) {
            @Override
            public void onTick(long l) {
                String sDuration = String.format(Locale.ENGLISH, "%02d"
                        , TimeUnit.MILLISECONDS.toSeconds(l)
                        , TimeUnit.MILLISECONDS.toSeconds(l) -
                                TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(1)));
                String c = Integer.toString(count);
                Log.d("COUNT-------->", c);
                if (count == 0) {
                    count = 10;
                    processsensordata();
                }
                else{
                    count = count - 1;
                }
            }

            @Override
            public void onFinish() {
                timerfunctionpower();
//                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
            }
        }.start();
    }
}