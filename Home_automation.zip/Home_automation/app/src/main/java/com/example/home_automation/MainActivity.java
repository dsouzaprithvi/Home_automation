package com.example.home_automation;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.home_automation.models.Status;
import com.example.home_automation.models.device1model;
import com.example.home_automation.models.device2model;
import com.example.home_automation.models.device3model;
import com.example.home_automation.models.device4model;
import com.example.home_automation.models.temphumimodel;
import com.google.firebase.auth.FirebaseAuth;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    CardView ai,motion, device_1, device_2, device_3, device_4;
    RelativeLayout relativeLayoutai, relativeLayoutmotion;
    TextView date, temperature, humidity, status, powerusage;
    ImageView status_icon;
    String currentDate;
    TextView device1power, device2power, device3power, device4power;
    int aiflag = 1, motionflag = 1;
    String phone = "+911234567890", currentTime;
    int count = 10;
    int flag = 0;

    ProgressDialog progressDialog;

    FirebaseAuth auth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        ai = findViewById(R.id.card_ai);
        motion = findViewById(R.id.card_motion);
        device_1 = findViewById(R.id.card_device1);
        device_2 = findViewById(R.id.card_device2);
        device_3 = findViewById(R.id.card_device3);
        device_4 = findViewById(R.id.card_device4);
        device1power = findViewById(R.id.device1power);
        device2power = findViewById(R.id.device2power);
        device3power = findViewById(R.id.device3power);
        device4power = findViewById(R.id.device4power);
        date = findViewById(R.id.date);
        relativeLayoutai = findViewById(R.id.relativeLayoutai);
        relativeLayoutmotion = findViewById(R.id.relativeLayoutmotion);
        temperature = findViewById(R.id.temperature);
        humidity = findViewById(R.id.humidity);
        status = findViewById(R.id.status);
        status_icon = findViewById(R.id.status_icon);
        powerusage = findViewById(R.id.powerUsage);

        progressDialog = new ProgressDialog(MainActivity.this);
        progressDialog.setTitle("Loading Values");
        progressDialog.show();

        auth = FirebaseAuth.getInstance();

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);


        currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        date.setText(currentDate);

        processstatus();







        ai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (aiflag == 0){
                    relativeLayoutai.setBackground(getResources().getDrawable(R.drawable.boxoff));
                    aiflag = 1;
                }else {
                    relativeLayoutai.setBackground(getResources().getDrawable(R.drawable.box));
                    aiflag = 0;
                }

            }
        });

        motion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (motionflag == 0){
                    relativeLayoutmotion.setBackground(getResources().getDrawable(R.drawable.boxoff));
                    motionflag = 1;
                }else {
                    relativeLayoutmotion.setBackground(getResources().getDrawable(R.drawable.box));
                    motionflag = 0;
                }

            }
        });

        device_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, Device_one.class));
            }
        });


        device_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, Device_two.class));
            }
        });

        device_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, Device_three.class));
            }
        });

        device_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, Device_four.class));
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);

        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement



        if (id == R.id.logout) {

            auth.signOut();
            Intent intent = new Intent(MainActivity.this, splash_screen.class);
            startActivity(intent);
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void processdata() {
//
        Call<List<temphumimodel>> call = apicontroller
                .getInstance()
                .getapi()
                .get();

        call.enqueue(new Callback<List<temphumimodel>>() {
            @Override
            public void onResponse(Call<List<temphumimodel>> call, Response<List<temphumimodel>> response) {
                List<temphumimodel> data = response.body();
                temperature.setText(data.get(0).getTemperature()+" \u2103");
                humidity.setText(data.get(0).getHumidity()+" %");

            }

            @Override
            public void onFailure(Call<List<temphumimodel>> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.toString(), Toast.LENGTH_LONG).show();

            }


        });
    }

    private void processdatadevice1() {
        Call<List<device1model>> calldevice1 = apicontroller
                .getInstance()
                .getapi()
                .getdevice1();

        calldevice1.enqueue(new Callback<List<device1model>>() {
            @Override
            public void onResponse(Call<List<device1model>> call, Response<List<device1model>> response) {
                List<device1model> power1 = response.body();
                device1power.setText(power1.get(0).getPower());

            }

            @Override
            public void onFailure(Call<List<device1model>> call, Throwable t) {

            }
        });
    }

    private void processdatadevice2() {
        Call<List<device2model>> calldevice2 = apicontroller
                .getInstance()
                .getapi()
                .getdevice2();

        calldevice2.enqueue(new Callback<List<device2model>>() {
            @Override
            public void onResponse(Call<List<device2model>> call, Response<List<device2model>> response) {
                List<device2model> power2 = response.body();
                device2power.setText(power2.get(0).getPower());
            }

            @Override
            public void onFailure(Call<List<device2model>> call, Throwable t) {

            }
        });
    }

    private void processdatadevice3() {
        Call<List<device3model>> calldevice3 = apicontroller
                .getInstance()
                .getapi()
                .getdevice3();

        calldevice3.enqueue(new Callback<List<device3model>>() {
            @Override
            public void onResponse(Call<List<device3model>> call, Response<List<device3model>> response) {
                List<device3model> power3 = response.body();
                device3power.setText(power3.get(0).getPower());
            }

            @Override
            public void onFailure(Call<List<device3model>> call, Throwable t) {

            }
        });
    }

    private void processdatadevice4() {
        Call<List<device4model>> calldevice4 = apicontroller
                .getInstance()
                .getapi()
                .getdevice4();

        calldevice4.enqueue(new Callback<List<device4model>>() {
            @Override
            public void onResponse(Call<List<device4model>> call, Response<List<device4model>> response) {
                List<device4model> power4 = response.body();
                device4power.setText(power4.get(0).getPower());
            }

            @Override
            public void onFailure(Call<List<device4model>> call, Throwable t) {

            }
        });

    }

    private void processstatus() {

        Call<List<Status>> callstatus = apicontroller
                .getInstance()
                .getapi()
                .getstatus();


        callstatus.enqueue(new Callback<List<Status>>() {
            @Override
            public void onResponse(Call<List<Status>> call, Response<List<Status>> response) {
                progressDialog.dismiss();
                List<Status> data = response.body();
                String mode = data.get(0).getServer();
                if (mode.equals("on")) {
                    status.setText("CONNECTED TO SERVER");
                    status_icon.setImageDrawable(getResources().getDrawable(R.drawable.ic_connected));
                    processdata();
                    processdatadevice1();
                    processdatadevice2();
                    processdatadevice3();
                    processdatadevice4();
                    Float power1 = Float.valueOf(device1power.getText().toString());
                    Float power2 = Float.valueOf(device2power.getText().toString());
                    Float power3 = Float.valueOf(device3power.getText().toString());
                    Float power4 = Float.valueOf(device4power.getText().toString());
                    Float total = power1 + power2 + power3 + power4;
                    String total_power = String.valueOf(total);
                    powerusage.setText(total_power+ " W");
                }else {
                    status.setText("CONNECTED TO GSM");
                    status_icon.setImageDrawable(getResources().getDrawable(R.drawable.ic_disconnected));
                }
                Log.i("Status----->", data.get(0).getServer());
            }

            @Override
            public void onFailure(Call<List<Status>> call, Throwable t) {
                status.setText("CONNECTED TO GSM");
                status_icon.setImageDrawable(getResources().getDrawable(R.drawable.ic_disconnected));
                String message = "STATUS";
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phone, null, message, null, null);
                flag = 0;
                currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                timerfunction();
            }
        });
    }

    private void status(){
        ContentResolver cResolver = getContentResolver();
        Cursor smsInboxCursor = cResolver.query(Uri.parse("content://sms/inbox"),
                null ,null, null, null);
        smsInboxCursor.moveToFirst();

        int indexBody = smsInboxCursor.getColumnIndex("body");
        int indexAddress = smsInboxCursor.getColumnIndex("address");
        int indexDate = smsInboxCursor.getColumnIndex("date");
        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        SimpleDateFormat tf = new SimpleDateFormat("HH:mm:ss");

        do {

            String body, sender, date, time;
            sender = smsInboxCursor.getString(indexAddress);
            body = smsInboxCursor.getString(indexBody).toString();
            date = df.format(smsInboxCursor.getLong(indexDate));
            time = tf.format(smsInboxCursor.getLong(indexDate));


            if (phone.equals(sender)){
                progressDialog.dismiss();
                String[] smsbody = body.split("\n");
                if(smsbody[0].matches("STATUS") && currentDate.matches(date) && currentTime.compareTo(time)<0 ){
                    Log.i("STASTATS-.........>>>>",smsbody[0]);
                    flag = 1;
                    String[] buffer1 = smsbody[1].split(" ");
                    temperature.setText(buffer1[2]+" \u2103");
                    String[] buffer2 = smsbody[2].split(" ");
                    humidity.setText(buffer2[2]+" %");
                    String[] buffer3 = smsbody[3].split(" ");
                    device1power.setText(buffer3[3]);
                    String[] buffer4 = smsbody[4].split(" ");
                    device2power.setText(buffer4[3]);
                    String[] buffer5 = smsbody[5].split(" ");
                    device3power.setText(buffer5[3]);
                    String[] buffer6 = smsbody[6].split(" ");
                    device4power.setText(buffer6[3]);
                    String[] buffer7 = smsbody[7].split(" ");
                    Float power1 = Float.valueOf(device1power.getText().toString());
                    Float power2 = Float.valueOf(device2power.getText().toString());
                    Float power3 = Float.valueOf(device3power.getText().toString());
                    Float power4 = Float.valueOf(device4power.getText().toString());
                    Float total = power1 + power2 + power3 + power4;
                    String total_power = String.valueOf(total);
                    powerusage.setText(total_power+ " W");


                }

            }
        }while (smsInboxCursor.moveToNext());
    }

    private void timerfunction() {
        long duration = TimeUnit.MINUTES.toMillis(1);
        new CountDownTimer(duration, 1000) {
            @Override
            public void onTick(long l) {
                String sDuration = String.format(Locale.ENGLISH, "%02d"
                        , TimeUnit.MILLISECONDS.toSeconds(l)
                        , TimeUnit.MILLISECONDS.toSeconds(l) -
                                TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(1)));
                String c = Integer.toString(count);
                Log.d("COUNT-------->", c);
                if (count == 0) {
                    count = 10;
                    status();
                }
                else{
                    count = count - 1;
                }
                if(flag == 1){
                    cancel();
                }

            }

            @Override
            public void onFinish() {
                progressDialog.dismiss();
            }
        }.start();


    }


}