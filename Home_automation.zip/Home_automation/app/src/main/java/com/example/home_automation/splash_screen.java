package com.example.home_automation;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class splash_screen extends AppCompatActivity {

    //Variables
    Animation topanim, bottomanim;
    ImageView logoimage;

    //duration for splash screen
    public static int SPLASH_SCREEN = 4000;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);



        //Animations
        topanim = AnimationUtils.loadAnimation(this, R.anim.top_animation);
        bottomanim = AnimationUtils.loadAnimation(this, R.anim.bottom_animation);


        //hooks
        logoimage = findViewById(R.id.logo);
        logoimage.setAnimation(topanim);


        //after animation is completed going to next activity
        new Handler().postDelayed(() -> {

            Intent intent = new Intent(splash_screen.this, otp_screen.class);
            startActivity(intent);
            finish();

        },SPLASH_SCREEN);

    }

}