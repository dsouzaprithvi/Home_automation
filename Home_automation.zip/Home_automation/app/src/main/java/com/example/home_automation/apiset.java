package com.example.home_automation;

import com.example.home_automation.models.Status;
import com.example.home_automation.models.device1model;
import com.example.home_automation.models.device2model;
import com.example.home_automation.models.device3model;
import com.example.home_automation.models.device4model;
import com.example.home_automation.models.temphumimodel;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

//Interface file to acces database
//Get and Post methods to load and store data on server

public interface apiset {

    @GET("fetch_temp_humidity.php")
    Call<List<temphumimodel>> get();

    @GET("fetch_device_1.php")
    Call<List<device1model>> getdevice1();

    @GET("fetch_device_2.php")
    Call<List<device2model>> getdevice2();

    @GET("fetch_device_3.php")
    Call<List<device3model>> getdevice3();

    @GET("fetch_device_4.php")
    Call<List<device4model>> getdevice4();

    @FormUrlEncoded
    @POST("update_device1.php")
        Call<device1model>getmessage1(
            @Field("status") String status,
            @Field("light_intensity") String light_intensity,
            @Field("power") String power,
            @Field("auto") String auto
    );

    @FormUrlEncoded
    @POST("update_device2.php")
    Call<device2model>getmessage2(
            @Field("status") String status,
            @Field("fan_speed") String fan_speed,
            @Field("power") String power,
            @Field("auto") String auto
    );

    @FormUrlEncoded
    @POST("update_device3.php")
    Call<device3model>getmessage3(
            @Field("status") String status,
            @Field("power") String power
    );

    @FormUrlEncoded
    @POST("update_device4.php")
    Call<device4model>getmessage4(
            @Field("status") String status,
            @Field("power") String power
    );

    @GET("fetch_status.php")
    Call<List<Status>> getstatus();


//
//    @FormUrlEncoded
//    @POST("insert.php")
//    Call<responsemodel>getmessage(
//            @Field("device_id") String device_id,
//            @Field("sms") String sms
//    );

}
