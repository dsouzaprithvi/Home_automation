package com.example.home_automation;

import com.example.home_automation.models.Status;
import com.example.home_automation.models.aipowermodel;
import com.example.home_automation.models.device1model;
import com.example.home_automation.models.device2model;
import com.example.home_automation.models.device3model;
import com.example.home_automation.models.device4model;
import com.example.home_automation.models.deviceupdatemodel;
import com.example.home_automation.models.sensordatamodel;
import com.example.home_automation.models.temphumimodel;
import com.example.home_automation.models.totalpowermodel;

import java.sql.Timestamp;
import java.util.List;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

//Interface file to acces database
//Get and Post methods to load and store data on server

public interface apiset {

    @GET("fetch_temp_humidity.php")
    Call<List<temphumimodel>> get();

    @GET("total_power.php")
    Call<List<totalpowermodel>> gettotalpower();

    @GET("bulb_total_power_consumption.php")
    Call<List<device1model>> getzerovalues1();

    @GET("fan_total_power_consumption.php")
    Call<List<device2model>> getzerovalues2();

    @GET("relay1_total_power_consumption.php")
    Call<List<device3model>> getzerovalues3();

    @GET("relay2_total_power_consumption.php")
    Call<List<device4model>> getzerovalues4();

    @GET("fetch_sensordata.php")
    Call<List<sensordatamodel>> getsensordata();

    @GET("fetch_status.php")
    Call<List<Status>> getstatus();

    @GET("fetch_aipower.php")
    Call<List<aipowermodel>> getaipower();

    @GET("fetch_withoutaipower.php")
    Call<List<aipowermodel>> getwithoutaipower();




    @FormUrlEncoded
    @POST("fetch_outputs.php")
    Call<List<deviceupdatemodel>>getdeviceinfo(
            @Field("name") String name
    );


    @FormUrlEncoded
    @POST("update_outputs.php")
    Call<deviceupdatemodel>getmessageupdate(
            @Field("name") String name,
            @Field("state") String state
    );

    @FormUrlEncoded
    @POST("insert_aipower.php")
    Call<aipowermodel>insertvalues(
            @Field("device1") String device1,
            @Field("device2") String device2,
            @Field("device3") String device3,
            @Field("device4") String device4,
            @Field("reading_time") long reading_time
    );

    @FormUrlEncoded
    @POST("insert_withoutaipower.php")
    Call<aipowermodel>insertvalues1(
            @Field("device1") String device1,
            @Field("device2") String device2,
            @Field("device3") String device3,
            @Field("device4") String device4,
            @Field("reading_time") long reading_time
    );
}
