package com.example.home_automation.models;


//Model to fetch data from server or store on server
//Constructors to define objects and Getter and setter to get and set respective values



public class device1model {

    String id, status, light_intensity, power, auto;

    String message;

    public device1model(String message) {
        this.message = message;
    }

    public device1model(String id, String status, String light_intensity, String power, String auto) {
        this.id = id;
        this.status = status;
        this.light_intensity = light_intensity;
        this.power = power;
        this.auto = auto;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getLight_intensity() {
        return light_intensity;
    }

    public void setLight_intensity(String light_intensity) {
        this.light_intensity = light_intensity;
    }

    public String getPower() {
        return power;
    }

    public void setPower(String power) {
        this.power = power;
    }

    public String getAuto() {
        return auto;
    }

    public void setAuto(String auto) {
        this.auto = auto;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
