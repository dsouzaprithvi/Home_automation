package com.example.home_automation.models;


//Model to fetch data from server or store on server
//Constructors to define objects and Getter and setter to get and set respective values


public class device4model {

    String id, status, power;

    String message;

    public device4model(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public device4model(String id, String status, String power) {
        this.id = id;
        this.status = status;
        this.power = power;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPower() {
        return power;
    }

    public void setPower(String power) {
        this.power = power;
    }
}
