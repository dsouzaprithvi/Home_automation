package com.example.home_automation.models;


//Model to fetch data from server or store on server
//Constructors to define objects and Getter and setter to get and set respective values


public class device4model {

    String id, status, power;

    String message;

    String Relay_2_Power_Value, reading_time;

    public device4model(String message) {
        this.message = message;
    }

    public device4model(String id, String relay_2_Power_Value, String reading_time) {
        this.id = id;
        Relay_2_Power_Value = relay_2_Power_Value;
        this.reading_time = reading_time;
    }

    public String getRelay_2_Power_Value() {
        return Relay_2_Power_Value;
    }

    public void setRelay_2_Power_Value(String relay_2_Power_Value) {
        Relay_2_Power_Value = relay_2_Power_Value;
    }

    public String getReading_time() {
        return reading_time;
    }

    public void setReading_time(String reading_time) {
        this.reading_time = reading_time;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }



    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPower() {
        return power;
    }

    public void setPower(String power) {
        this.power = power;
    }
}
