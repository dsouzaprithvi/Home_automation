package com.example.home_automation;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class Device_two extends AppCompatActivity {


    SwitchCompat switch_button;
    ImageView fan_image;
    Button auto;
    int i=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_two);

        switch_button = findViewById(R.id.switch_button);
        fan_image = findViewById(R.id.fan);
        auto = findViewById(R.id.auto);

        switch_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(switch_button.isChecked()){
                    fan_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_ceiling_fan));
                }
                else{
                    fan_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_ceiling_fan_off));
                }
            }
        });

        auto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(i==0){
                    auto.setBackgroundColor(getResources().getColor(R.color.black));
                    i=1;
                }
                else{
                    auto.setBackgroundColor(getResources().getColor(R.color.teal_200));
                    i=0;
                }
            }
        });
    }
}