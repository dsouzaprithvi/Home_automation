package com.example.home_automation;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.home_automation.models.device1model;
import com.example.home_automation.models.device2model;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import me.tankery.lib.circularseekbar.CircularSeekBar;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Device_two extends AppCompatActivity {


    SwitchCompat switch_button;
    ImageView fan_image;
    TextView speedvalue;
    Button auto;
    int i=0;
    ProgressDialog progressDialog;


    String phone = "+911234567890", currentTime , currentDate;
    int count = 10;
    int flag = 0;
    boolean server = true;

    CircularSeekBar circularSeekBar;

    List<device2model> data;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_two);

        switch_button = findViewById(R.id.switch_button);
        fan_image = findViewById(R.id.fan);
        auto = findViewById(R.id.auto);
        speedvalue = findViewById(R.id.speed_value);
        circularSeekBar = findViewById(R.id.circular_seekbar);

        progressDialog = new ProgressDialog(Device_two.this);
        progressDialog.setTitle("Loading Values");
        progressDialog.show();


        processdata();


        circularSeekBar.setOnSeekBarChangeListener(new CircularSeekBar.OnCircularSeekBarChangeListener() {
            @Override
            public void onProgressChanged(CircularSeekBar circularSeekBar, float progress, boolean fromUser) {
                int i = (int) progress;
                speedvalue.setText(""+i);
                if (i == 0){
                    fan_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_ceiling_fan_off));
                    switch_button.setChecked(false);
                } else {
                    fan_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_ceiling_fan));
                    switch_button.setChecked(true);
                }
                String status;
                if (switch_button.isChecked()) {
                    status = "on";
                } else {
                    status = "off";
                }
                storedata(status, ""+i, "50", data.get(0).getAuto());
            }

            @Override
            public void onStopTrackingTouch(CircularSeekBar seekBar) {

            }

            @Override
            public void onStartTrackingTouch(CircularSeekBar seekBar) {

            }
        });

        switch_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               if (server) {
                   if(switch_button.isChecked()){
                       fan_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_ceiling_fan));
                       storedata("on", "99", "50", "off");
                       circularSeekBar.setVisibility(View.VISIBLE);
                       circularSeekBar.setProgress(99);
                   }
                   else{
                       fan_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_ceiling_fan_off));
                       storedata("off", "0", "50", "off");
                       circularSeekBar.setProgress(0);
                   }
               }else {
                   progressDialog.show();
                   if(switch_button.isChecked()) {
                       fan_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_ceiling_fan));
                       String message = "fan 75";
                       SmsManager smsManager = SmsManager.getDefault();
                       smsManager.sendTextMessage(phone, null, message, null, null);
                       flag = 0;
                       currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                       currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                       timerfunction();
                   } else {
                       fan_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_ceiling_fan_off));
                       String message = "fan 0";
                       SmsManager smsManager = SmsManager.getDefault();
                       smsManager.sendTextMessage(phone, null, message, null, null);
                       flag = 0;
                       currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                       currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                       timerfunction();
                   }
               }
            }
        });

        auto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String status;
                if (switch_button.isChecked()) {
                    status = "on";
                } else {
                    status = "off";
                }
                if (server) {
                    if (auto.getText().toString().equals("Auto")) {
                        auto.setBackgroundColor(getResources().getColor(R.color.black));
                        auto.setText("Maunal");
                        i = 1;
                        switch_button.setVisibility(View.VISIBLE);
                        circularSeekBar.setVisibility(View.VISIBLE);
                        speedvalue.setVisibility(View.VISIBLE);
                        storedata(status, speedvalue.getText().toString(), "50", "off");
                    } else {
                        auto.setBackgroundColor(getResources().getColor(R.color.teal_200));
                        auto.setText("Auto");
                        switch_button.setVisibility(View.INVISIBLE);
                        circularSeekBar.setVisibility(View.INVISIBLE);
                        speedvalue.setVisibility(View.INVISIBLE);
                        i = 0;
                        storedata(status, speedvalue.getText().toString(), "50", "on");
                    }
                }else {
                    progressDialog.show();
                    if(auto.getText().toString().equals("Auto")) {
                        auto.setBackgroundColor(getResources().getColor(R.color.black));
                        auto.setText("Maunal");
                        i=1;
                        switch_button.setVisibility(View.VISIBLE);
                        String message = "fan a";
                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(phone, null, message, null, null);
                        flag = 0;
                        currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                        currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                        timerfunction();
                    } else {
                        auto.setBackgroundColor(getResources().getColor(R.color.teal_200));
                        auto.setText("Auto");
                        switch_button.setVisibility(View.INVISIBLE);
                        i=0;
                        String message = "fan 0";
                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(phone, null, message, null, null);
                        flag = 0;
                        currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                        currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                        timerfunction();

                    }
                }
            }
        });
    }

    private void processdata() {

        Call<List<device2model>> call = apicontroller
                .getInstance()
                .getapi()
                .getdevice2();
        
        call.enqueue(new Callback<List<device2model>>() {
            @Override
            public void onResponse(Call<List<device2model>> call, Response<List<device2model>> response) {
                progressDialog.dismiss();
                data = response.body();
                speedvalue.setText(data.get(0).getFan_speed());
                Float i = Float.valueOf(data.get(0).getFan_speed());
                circularSeekBar.setProgress(i);
                
                if (data.get(0).getAuto().equals("on")) {
                    auto.setBackgroundColor(getResources().getColor(R.color.teal_200));
                    auto.setText("Auto");
                    switch_button.setVisibility(View.INVISIBLE);
                    circularSeekBar.setVisibility(View.INVISIBLE);
                    speedvalue.setVisibility(View.INVISIBLE);

                } else {
                    auto.setBackgroundColor(getResources().getColor(R.color.black));
                    auto.setText("Manual");
                    switch_button.setVisibility(View.VISIBLE);
                    circularSeekBar.setVisibility(View.VISIBLE);
                    speedvalue.setVisibility(View.VISIBLE);
                    String status = data.get(0).getStatus();
                    if (status.equals("on")){
                        switch_button.setChecked(true);
                        fan_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_ceiling_fan));
                        circularSeekBar.setVisibility(View.VISIBLE);
                    } else {
                        switch_button.setChecked(false);
                        fan_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_ceiling_fan_off));
                    }

                }

                
            }

            @Override
            public void onFailure(Call<List<device2model>> call, Throwable t) {
                circularSeekBar.setVisibility(View.INVISIBLE);
                speedvalue.setVisibility(View.INVISIBLE);
                server = false;
                String message = "device2";
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phone, null, message, null, null);
                flag = 0;
                currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                timerfunction();
            }
        });
    }

    private void storedata(String status, String fan_speed, String power, String auto) {
        Call<device2model> call2 = apicontroller
                .getInstance()
                .getapi()
                .getmessage2(status, fan_speed, power, auto);

        call2.enqueue(new Callback<device2model>() {
            @Override
            public void onResponse(Call<device2model> call, Response<device2model> response) {
                device2model mess = response.body();
                if (mess.getMessage().equals("inserted")){
                    Toast.makeText(getApplicationContext(), "sms inserted", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<device2model> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.toString(), Toast.LENGTH_LONG).show();
                Log.i("error------>", t.toString());
            }
        });
    }


    private void status(){
        ContentResolver cResolver = getContentResolver();
        Cursor smsInboxCursor = cResolver.query(Uri.parse("content://sms/inbox"),
                null ,null, null, null);
        smsInboxCursor.moveToFirst();

        int indexBody = smsInboxCursor.getColumnIndex("body");
        int indexAddress = smsInboxCursor.getColumnIndex("address");
        int indexDate = smsInboxCursor.getColumnIndex("date");
        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        SimpleDateFormat tf = new SimpleDateFormat("HH:mm:ss");

        do {

            String body, sender, date, time;
            sender = smsInboxCursor.getString(indexAddress);
            body = smsInboxCursor.getString(indexBody).toString();
            date = df.format(smsInboxCursor.getLong(indexDate));
            time = tf.format(smsInboxCursor.getLong(indexDate));


            if (phone.equals(sender)){
                progressDialog.dismiss();
                String[] smsbody = body.split("\n");
                if(smsbody[0].matches("DEVICE2") && currentDate.matches(date) && currentTime.compareTo(time)<0 ){
                    Log.i("STASTATS-.........>>>>",smsbody[0]);
                    flag = 1;
                    String[] buffer1 = smsbody[1].split(" ");
                    if (buffer1[2].equals("on")){
                        switch_button.setChecked(true);
                        fan_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_ceiling_fan));
                        circularSeekBar.setVisibility(View.INVISIBLE);
                    } else {
                        switch_button.setChecked(false);
                        fan_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_ceiling_fan_off));
                        circularSeekBar.setVisibility(View.INVISIBLE);
                    }


                    String[] buffer3 = smsbody[2].split(" ");
                    if ( buffer3[2].equals("on")) {
                        auto.setBackgroundColor(getResources().getColor(R.color.teal_200));
                        auto.setText("Auto");
                        switch_button.setVisibility(View.INVISIBLE);
                    }else {
                        auto.setBackgroundColor(getResources().getColor(R.color.black));
                        auto.setText("Maunal");
                        switch_button.setVisibility(View.VISIBLE);
                    }
                }

            }
        }while (smsInboxCursor.moveToNext());
    }

    private void timerfunction() {
        long duration = TimeUnit.MINUTES.toMillis(1);
        new CountDownTimer(duration, 1000) {
            @Override
            public void onTick(long l) {
                String sDuration = String.format(Locale.ENGLISH, "%02d"
                        , TimeUnit.MILLISECONDS.toSeconds(l)
                        , TimeUnit.MILLISECONDS.toSeconds(l) -
                                TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(1)));
                String c = Integer.toString(count);
                Log.d("COUNT-------->", c);
                if (count == 0) {
                    count = 10;
                    status();
                }
                else{
                    count = count - 1;
                }
                if(flag == 1){
                    cancel();
                }

            }

            @Override
            public void onFinish() {
                progressDialog.dismiss();
            }
        }.start();


    }
}