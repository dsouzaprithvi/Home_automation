package com.example.home_automation;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.home_automation.models.device1model;
import com.example.home_automation.models.device2model;
import com.example.home_automation.models.deviceupdatemodel;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import me.tankery.lib.circularseekbar.CircularSeekBar;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Device_two extends AppCompatActivity {


    SwitchCompat switch_button;
    ImageView fan_image;
    TextView speedvalue;
    Button auto;
    int i = 0;
    ProgressDialog progressDialog;


    String phone, currentTime, currentDate;
    int count = 10;
    int flag = 0;
    boolean server = true;

    CircularSeekBar circularSeekBar;

    List<device2model> data;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_two);

        SharedPreferences sharedPreferences = getSharedPreferences("phonenumber", 0);
        phone = sharedPreferences.getString("Device_number", String.valueOf(0));



        switch_button = findViewById(R.id.switch_button);
        fan_image = findViewById(R.id.fan);
        auto = findViewById(R.id.auto);
        speedvalue = findViewById(R.id.speed_value);
        circularSeekBar = findViewById(R.id.circular_seekbar);

        progressDialog = new ProgressDialog(Device_two.this);
        progressDialog.setTitle("Loading Values");
        progressDialog.show();


        processdata1("FAN_A");


        circularSeekBar.setOnSeekBarChangeListener(new CircularSeekBar.OnCircularSeekBarChangeListener() {
            @Override
            public void onProgressChanged(CircularSeekBar circularSeekBar, float progress, boolean fromUser) {
                int i = (int) progress;
                speedvalue.setText("" + i);
                if (i == 0) {
                    fan_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_ceiling_fan_off));
                    switch_button.setChecked(false);
                } else {
                    fan_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_ceiling_fan));
                    switch_button.setChecked(true);
                }
                storeoutputsdata("FAN_M", String.valueOf(i));
            }

            @Override
            public void onStopTrackingTouch(CircularSeekBar seekBar) {

            }

            @Override
            public void onStartTrackingTouch(CircularSeekBar seekBar) {

            }
        });

        switch_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (server) {
                    if (switch_button.isChecked()) {
                        fan_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_ceiling_fan));
                        storeoutputsdata("FAN_M", "70");
                        circularSeekBar.setVisibility(View.VISIBLE);
                        circularSeekBar.setProgress(75);
                    } else {
                        fan_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_ceiling_fan_off));
                        storeoutputsdata("FAN_M", "0");
                        circularSeekBar.setProgress(0);
                    }
                } else {
                    progressDialog.show();
                    if (switch_button.isChecked()) {
                        fan_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_ceiling_fan));
                        String message = "fan 70";
                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(phone, null, message, null, null);
                        flag = 0;
                        currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                        currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                        timerfunction();
                    } else {
                        fan_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_ceiling_fan_off));
                        String message = "fan o";
                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(phone, null, message, null, null);
                        flag = 0;
                        currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                        currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                        timerfunction();
                    }
                }
            }
        });

        auto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (server) {
                    if (auto.getText().toString().equals("Auto")) {
                        auto.setBackgroundColor(getResources().getColor(R.color.black));
                        auto.setText("Maunal");
                        switch_button.setVisibility(View.VISIBLE);
                        circularSeekBar.setVisibility(View.VISIBLE);
                        speedvalue.setVisibility(View.VISIBLE);
                        storeoutputsdata("FAN_A", "0");
                        i = 1;
                    } else {
                        auto.setBackgroundColor(getResources().getColor(R.color.teal_200));
                        auto.setText("Auto");
                        switch_button.setVisibility(View.INVISIBLE);
                        circularSeekBar.setVisibility(View.INVISIBLE);
                        speedvalue.setVisibility(View.INVISIBLE);
                        storeoutputsdata("FAN_A", "1");
                        switch_button.setChecked(false);
                        circularSeekBar.setProgress(0);
                        storeoutputsdata("FAN_M", "0");
                    }
                } else {
                    progressDialog.show();
                    if (auto.getText().toString().equals("Auto")) {
                        auto.setBackgroundColor(getResources().getColor(R.color.black));
                        auto.setText("Maunal");
                        switch_button.setVisibility(View.VISIBLE);
                        String message = "fan o";
                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(phone, null, message, null, null);
                        flag = 0;
                        currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                        currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                        timerfunction();
                    } else {
                        auto.setBackgroundColor(getResources().getColor(R.color.teal_200));
                        auto.setText("Auto");
                        switch_button.setVisibility(View.INVISIBLE);
                        String message = "fan a";
                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(phone, null, message, null, null);
                        flag = 0;
                        currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                        currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                        timerfunction();

                    }
                }
            }
        });
    }

    private void processdata1(String name) {
        Call<List<deviceupdatemodel>> call = apicontroller
                .getInstance()
                .getapi()
                .getdeviceinfo(name);

        call.enqueue(new Callback<List<deviceupdatemodel>>() {
            @Override
            public void onResponse(Call<List<deviceupdatemodel>> call, Response<List<deviceupdatemodel>> response) {
                progressDialog.dismiss();
                List<deviceupdatemodel> data = response.body();
                server = true;
                if (data.get(0).getState().equals("1")) {
                    auto.setBackgroundColor(getResources().getColor(R.color.teal_200));
                    auto.setText("Auto");
                    switch_button.setVisibility(View.INVISIBLE);
                    circularSeekBar.setVisibility(View.INVISIBLE);
                    speedvalue.setVisibility(View.INVISIBLE);
                } else {
                    auto.setBackgroundColor(getResources().getColor(R.color.black));
                    auto.setText("Manual");
                    switch_button.setVisibility(View.VISIBLE);
                    circularSeekBar.setVisibility(View.VISIBLE);
                    speedvalue.setVisibility(View.VISIBLE);
                    processdataswitch("FAN_M");
                }

            }

            @Override
            public void onFailure(Call<List<deviceupdatemodel>> call, Throwable t) {
                circularSeekBar.setVisibility(View.INVISIBLE);
                speedvalue.setVisibility(View.INVISIBLE);
                server = false;
                String message = "device2";
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phone, null, message, null, null);
                flag = 0;
                currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                timerfunction();
            }
        });


    }

    private void processdataswitch(String name) {
        Call<List<deviceupdatemodel>> call = apicontroller
                .getInstance()
                .getapi()
                .getdeviceinfo(name);

        call.enqueue(new Callback<List<deviceupdatemodel>>() {
            @Override
            public void onResponse(Call<List<deviceupdatemodel>> call, Response<List<deviceupdatemodel>> response) {
                List<deviceupdatemodel> data = response.body();
                if (data.get(0).getState().equals("0")) {
                    switch_button.setChecked(false);
                    fan_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_ceiling_fan_off));
                    circularSeekBar.setProgress(0);
                } else {
                    switch_button.setChecked(true);
                    fan_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_ceiling_fan));
                    circularSeekBar.setProgress(Integer.parseInt(data.get(0).getState()));
                }


            }

            @Override
            public void onFailure(Call<List<deviceupdatemodel>> call, Throwable t) {
                Log.i("Device 1 ---->>>>>>>>>>", t.getMessage());
            }
        });
    }


    //Store data on server
    private void storeoutputsdata(String name, String state) {

        Call<deviceupdatemodel> call = apicontroller
                .getInstance()
                .getapi()
                .getmessageupdate(name, state);

        call.enqueue(new Callback<deviceupdatemodel>() {
            @Override
            public void onResponse(Call<deviceupdatemodel> call, Response<deviceupdatemodel> response) {
                deviceupdatemodel mess = response.body();
                if (mess.getMessage().equals("inserted")) {
                    Toast.makeText(getApplicationContext(), "sms inserted", Toast.LENGTH_LONG).show();
                }
                if ( i == 1 ) {
                    processdata1("FAN_M");
                    i = 0;
                }

            }

            @Override
            public void onFailure(Call<deviceupdatemodel> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.toString(), Toast.LENGTH_LONG).show();
                Log.i("error------>", t.toString());
            }
        });

    }





    private void status() {
        ContentResolver cResolver = getContentResolver();
        Cursor smsInboxCursor = cResolver.query(Uri.parse("content://sms/inbox"),
                null, null, null, null);
        smsInboxCursor.moveToFirst();

        int indexBody = smsInboxCursor.getColumnIndex("body");
        int indexAddress = smsInboxCursor.getColumnIndex("address");
        int indexDate = smsInboxCursor.getColumnIndex("date");
        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        SimpleDateFormat tf = new SimpleDateFormat("HH:mm:ss");

        do {

            String body, sender, date, time;
            sender = smsInboxCursor.getString(indexAddress);
            body = smsInboxCursor.getString(indexBody).toString();
            date = df.format(smsInboxCursor.getLong(indexDate));
            time = tf.format(smsInboxCursor.getLong(indexDate));


            if (phone.equals(sender)) {

                String[] smsbody = body.split("\n");
                if (smsbody[0].matches("DEVICE_2") && currentDate.matches(date) && currentTime.compareTo(time) < 0) {
                    progressDialog.dismiss();
                    Log.i("STASTATS-.........>>>>", smsbody[0]);
                    flag = 1;
                    String[] buffer1 = smsbody[1].split(" ");
                    if (buffer1[2].equals("on")) {
                        switch_button.setChecked(true);
                        fan_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_ceiling_fan));
                        circularSeekBar.setVisibility(View.INVISIBLE);
                    } else {
                        switch_button.setChecked(false);
                        fan_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_ceiling_fan_off));
                        circularSeekBar.setVisibility(View.INVISIBLE);
                    }


                    String[] buffer3 = smsbody[2].split(" ");
                    if (buffer3[2].equals("on")) {
                        auto.setBackgroundColor(getResources().getColor(R.color.teal_200));
                        auto.setText("Auto");
                        switch_button.setVisibility(View.INVISIBLE);
                    } else {
                        auto.setBackgroundColor(getResources().getColor(R.color.black));
                        auto.setText("Maunal");
                        switch_button.setVisibility(View.VISIBLE);
                    }
                }

            }
        } while (smsInboxCursor.moveToNext());
    }

    private void timerfunction() {
        long duration = TimeUnit.MINUTES.toMillis(1);
        new CountDownTimer(duration, 1000) {
            @Override
            public void onTick(long l) {
                String sDuration = String.format(Locale.ENGLISH, "%02d"
                        , TimeUnit.MILLISECONDS.toSeconds(l)
                        , TimeUnit.MILLISECONDS.toSeconds(l) -
                                TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(1)));
                String c = Integer.toString(count);
                Log.d("COUNT-------->", c);
                if (count == 0) {
                    count = 10;
                    status();
                } else {
                    count = count - 1;
                }
                if (flag == 1) {
                    cancel();
                }

            }

            @Override
            public void onFinish() {
                progressDialog.dismiss();
            }
        }.start();


    }
}