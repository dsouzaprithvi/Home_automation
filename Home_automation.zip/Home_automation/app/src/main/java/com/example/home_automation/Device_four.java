package com.example.home_automation;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.home_automation.models.device3model;
import com.example.home_automation.models.device4model;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Device_four extends AppCompatActivity {

    // Initialization
    SwitchCompat switch_button;
    ImageView induction_image;
    List<device4model> data;

    ProgressDialog progressDialog;

    String phone = "+911234567890", currentTime , currentDate;
    int count = 10;
    int flag = 0;
    boolean server = true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_four);

        //hooks to connect the buttons and textviews
        switch_button = findViewById(R.id.switch_button);
        induction_image = findViewById(R.id.light_bulb);

        progressDialog = new ProgressDialog(Device_four.this);
        progressDialog.setTitle("Loading Values");
        progressDialog.show();

        processdata();

        //onclick function
        switch_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //if server is connected
                if (server) {
                    if(switch_button.isChecked()){
                        induction_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_induction_stove));
                        storedata("on", "100");
                    }
                    else{
                        induction_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_induction_stove_off));
                        storedata("off","100");
                    }
                } else {
                    progressDialog.show();
                    // if server not connected
                    if(switch_button.isChecked()) {
                       induction_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_induction_stove));
                       //Send message
                       String message = "relay2 on";
                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(phone, null, message, null, null);
                        flag = 0;
                        currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                        currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                        timerfunction();
                    } else {
                        induction_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_induction_stove_off));
                        String message = "relay2 off";
                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(phone, null, message, null, null);
                        flag = 0;
                        currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                        currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                        timerfunction();
                    }
                }
            }
        });
    }

    private void processdata() {
        //get values from server
        Call<List<device4model>> call = apicontroller
                .getInstance()
                .getapi()
                .getdevice4();

        call.enqueue(new Callback<List<device4model>>() {
            @Override
            public void onResponse(Call<List<device4model>> call, Response<List<device4model>> response) {
                progressDialog.dismiss();
                data = response.body();
                String status = data.get(0).getStatus();
                if (status.equals("on")){
                    switch_button.setChecked(true);
                    induction_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_induction_stove));
                } else {
                    switch_button.setChecked(false);
                    induction_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_induction_stove_off));
                }
            }

            @Override
            public void onFailure(Call<List<device4model>> call, Throwable t) {
                //use sms when no server
                server = false;
                String message = "device4";
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phone, null, message, null, null);
                flag = 0;
                currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                timerfunction();
            }
        });
    }

    private void storedata(String status, String power) {

        //store data on server
        Call<device4model> call2 = apicontroller
                .getInstance()
                .getapi()
                .getmessage4(status, power);

        call2.enqueue(new Callback<device4model>() {
            @Override
            public void onResponse(Call<device4model> call, Response<device4model> response) {
                device4model mess = response.body();
                if (mess.getMessage().equals("inserted")){
                    Toast.makeText(getApplicationContext(), "sms inserted", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<device4model> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.toString(), Toast.LENGTH_LONG).show();
                Log.i("error------>", t.toString());
            }
        });
    }

    private void status(){
        //read sms from sms inbox from phone
        ContentResolver cResolver = getContentResolver();
        Cursor smsInboxCursor = cResolver.query(Uri.parse("content://sms/inbox"),
                null ,null, null, null);
        smsInboxCursor.moveToFirst();

        int indexBody = smsInboxCursor.getColumnIndex("body");
        int indexAddress = smsInboxCursor.getColumnIndex("address");
        int indexDate = smsInboxCursor.getColumnIndex("date");
        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        SimpleDateFormat tf = new SimpleDateFormat("HH:mm:ss");

        do {

            String body, sender, date, time;
            sender = smsInboxCursor.getString(indexAddress);
            body = smsInboxCursor.getString(indexBody).toString();
            date = df.format(smsInboxCursor.getLong(indexDate));
            time = tf.format(smsInboxCursor.getLong(indexDate));


            //Fetch sms from the number stored
            if (phone.equals(sender)){
                progressDialog.dismiss();
                String[] smsbody = body.split("\n");
                if(smsbody[0].matches("DEVICE4") && currentDate.matches(date) && currentTime.compareTo(time)<0 ){
                    Log.i("STASTATS-.........>>>>",smsbody[0]);
                    flag = 1;
                    String[] buffer1 = smsbody[1].split(" ");
                    if (buffer1[2].equals("on")){
                        switch_button.setChecked(true);
                        induction_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_induction_stove));
                    } else {
                        switch_button.setChecked(false);
                        induction_image.setImageDrawable(getResources().getDrawable(R.drawable.ic_induction_stove_off));
                    }


                }

            }
        }while (smsInboxCursor.moveToNext());
    }

    private void timerfunction() {
        //to wait till sms is received after the sms from phone is sent
        long duration = TimeUnit.MINUTES.toMillis(1);
        new CountDownTimer(duration, 1000) {
            @Override
            public void onTick(long l) {
                String sDuration = String.format(Locale.ENGLISH, "%02d"
                        , TimeUnit.MILLISECONDS.toSeconds(l)
                        , TimeUnit.MILLISECONDS.toSeconds(l) -
                                TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(1)));
                String c = Integer.toString(count);
                Log.d("COUNT-------->", c);
                if (count == 0) {
                    count = 10;
                    status();
                }
                else{
                    count = count - 1;
                }
                if(flag == 1){
                    cancel();
                }

            }

            @Override
            public void onFinish() {
                progressDialog.dismiss();
            }
        }.start();


    }
}