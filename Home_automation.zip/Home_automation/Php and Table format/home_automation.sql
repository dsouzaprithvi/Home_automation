-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 19, 2022 at 12:46 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `home_automation`
--

-- --------------------------------------------------------

--
-- Table structure for table `boards`
--

CREATE TABLE `boards` (
  `id` int(6) UNSIGNED NOT NULL,
  `board` int(6) DEFAULT NULL,
  `last_request` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `boards`
--

INSERT INTO `boards` (`id`, `board`, `last_request`) VALUES
(1, 1, '2022-05-18 08:17:50');

-- --------------------------------------------------------

--
-- Table structure for table `device_1`
--

CREATE TABLE `device_1` (
  `id` int(11) NOT NULL,
  `status` text NOT NULL,
  `light_intensity` text NOT NULL,
  `power` text NOT NULL,
  `auto` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `device_1`
--

INSERT INTO `device_1` (`id`, `status`, `light_intensity`, `power`, `auto`) VALUES
(1, 'off', '0', '200', 'off');

-- --------------------------------------------------------

--
-- Table structure for table `device_2`
--

CREATE TABLE `device_2` (
  `id` int(11) NOT NULL,
  `status` text NOT NULL,
  `fan_speed` text NOT NULL,
  `power` text NOT NULL,
  `auto` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `device_2`
--

INSERT INTO `device_2` (`id`, `status`, `fan_speed`, `power`, `auto`) VALUES
(1, 'on', '12', '100', 'off');

-- --------------------------------------------------------

--
-- Table structure for table `device_3`
--

CREATE TABLE `device_3` (
  `id` int(11) NOT NULL,
  `status` text NOT NULL,
  `power` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `device_3`
--

INSERT INTO `device_3` (`id`, `status`, `power`) VALUES
(1, 'on', '200');

-- --------------------------------------------------------

--
-- Table structure for table `device_4`
--

CREATE TABLE `device_4` (
  `id` int(11) NOT NULL,
  `status` text NOT NULL,
  `power` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `device_4`
--

INSERT INTO `device_4` (`id`, `status`, `power`) VALUES
(1, 'on', '200');

-- --------------------------------------------------------

--
-- Table structure for table `outputs`
--

CREATE TABLE `outputs` (
  `id` int(6) UNSIGNED NOT NULL,
  `name` varchar(64) DEFAULT NULL,
  `board` int(6) DEFAULT NULL,
  `gpio` int(6) DEFAULT NULL,
  `state` int(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `outputs`
--

INSERT INTO `outputs` (`id`, `name`, `board`, `gpio`, `state`) VALUES
(2, 'Relay_1', 1, 26, 0),
(3, 'Relay_2', 1, 27, 0),
(4, 'BULB_M', 1, 140, 0),
(5, 'BULB_A', 1, 141, 1),
(6, 'FAN_M', 1, 330, 0),
(7, 'FAN_A', 1, 331, 1);

-- --------------------------------------------------------

--
-- Table structure for table `powerusage`
--

CREATE TABLE `powerusage` (
  `id` int(11) NOT NULL,
  `device` text NOT NULL,
  `date` text NOT NULL,
  `power` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `sensordata`
--

CREATE TABLE `sensordata` (
  `id` int(6) UNSIGNED NOT NULL,
  `TemperatureValue` varchar(10) DEFAULT NULL,
  `HumidityValue` varchar(10) DEFAULT NULL,
  `LightSensorValue` varchar(10) DEFAULT NULL,
  `Relay_1_Power_Value` varchar(10) DEFAULT NULL,
  `Relay_2_Power_Value` varchar(10) DEFAULT NULL,
  `Bulb_Power_Value` varchar(10) DEFAULT NULL,
  `Fan_Power_Value` varchar(10) DEFAULT NULL,
  `reading_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sensordata`
--

INSERT INTO `sensordata` (`id`, `TemperatureValue`, `HumidityValue`, `LightSensorValue`, `Relay_1_Power_Value`, `Relay_2_Power_Value`, `Bulb_Power_Value`, `Fan_Power_Value`, `reading_time`) VALUES
(1, '25', '90', '75', '100', '100', '100', '100', '2022-05-17 06:53:23'),
(2, '30', '90', '75', '100', '100', '100', '100', '2022-05-17 06:53:55'),
(3, '25', '90', '75', '100', '100', '100', '100', '2022-05-17 06:56:36'),
(4, '40', '80', '50', '200', '200', '200', '200', '2022-05-17 07:18:36'),
(5, '29.00', '57.00', '2045', '0', '0', '0', '0', '2022-05-18 06:24:14'),
(6, '29.00', '57.00', '2054', '0', '0', '0', '0', '2022-05-18 06:24:23'),
(7, '29.00', '58.00', '1968', '0', '0', '39', '61', '2022-05-18 06:24:32'),
(8, '29.00', '57.00', '1990', '0', '0', '40', '65', '2022-05-18 06:24:41'),
(9, '29.00', '57.00', '1985', '0', '0', '39', '60', '2022-05-18 06:24:50'),
(10, '29.00', '57.00', '2037', '0', '0', '37', '62', '2022-05-18 06:24:58'),
(11, '29.10', '57.00', '2020', '0', '0', '36', '60', '2022-05-18 06:25:07'),
(12, '29.10', '57.00', '1935', '0', '0', '36', '60', '2022-05-18 06:25:16'),
(13, '29.10', '57.00', '1922', '0', '0', '35', '61', '2022-05-18 06:25:28'),
(14, '29.10', '57.00', '1937', '0', '0', '35', '57', '2022-05-18 06:25:36'),
(15, '29.00', '57.00', '2003', '0', '0', '38', '62', '2022-05-18 06:25:45'),
(16, '29.00', '57.00', '1966', '0', '0', '35', '61', '2022-05-18 06:25:54'),
(17, '29.00', '57.00', '2011', '0', '0', '0', '60', '2022-05-18 06:26:03'),
(18, '29.00', '58.00', '1961', '0', '0', '0', '0', '2022-05-18 06:26:15'),
(19, '29.00', '58.00', '1990', '0', '0', '0', '66', '2022-05-18 06:26:24'),
(20, '29.00', '58.00', '1975', '0', '0', '0', '0', '2022-05-18 06:26:33'),
(21, '29.00', '58.00', '1970', '0', '0', '0', '59', '2022-05-18 06:26:42'),
(22, '29.00', '58.00', '1970', '0', '0', '0', '59', '2022-05-18 06:26:50'),
(23, '29.00', '58.00', '2043', '0', '0', '0', '65', '2022-05-18 06:26:59'),
(24, '29.00', '58.00', '2025', '28', '0', '0', '66', '2022-05-18 06:27:08'),
(25, '29.00', '58.00', '1985', '0', '0', '0', '61', '2022-05-18 06:27:17'),
(26, '29.00', '58.00', '2075', '0', '20', '0', '64', '2022-05-18 06:27:26'),
(27, '29.00', '58.00', '2063', '0', '0', '0', '62', '2022-05-18 06:27:34'),
(28, '29.00', '58.00', '2033', '0', '0', '0', '67', '2022-05-18 06:27:43'),
(29, '29.00', '58.00', '2068', '0', '0', '0', '62', '2022-05-18 06:27:52'),
(30, '29.00', '58.00', '2032', '0', '0', '0', '64', '2022-05-18 06:28:01'),
(31, '29.00', '58.00', '2028', '0', '0', '0', '61', '2022-05-18 06:28:12'),
(32, '29.00', '58.00', '2038', '0', '0', '0', '61', '2022-05-18 06:28:21'),
(33, '29.00', '58.00', '1999', '0', '0', '0', '60', '2022-05-18 06:28:30'),
(34, '29.00', '58.00', '2029', '0', '0', '0', '62', '2022-05-18 06:28:39'),
(35, '29.00', '57.00', '1991', '0', '0', '0', '64', '2022-05-18 06:28:49'),
(36, '29.00', '57.00', '2017', '0', '0', '0', '64', '2022-05-18 06:28:57'),
(37, '29.00', '57.00', '1989', '0', '0', '0', '64', '2022-05-18 06:29:06'),
(38, '29.00', '57.00', '1966', '0', '0', '0', '59', '2022-05-18 06:29:15'),
(39, '29.00', '57.00', '2001', '0', '0', '0', '66', '2022-05-18 06:29:24'),
(40, '29.00', '57.00', '1957', '0', '0', '0', '60', '2022-05-18 06:29:45'),
(41, '29.00', '57.00', '2070', '0', '0', '0', '64', '2022-05-18 06:29:48'),
(42, '29.00', '57.00', '1995', '0', '0', '0', '61', '2022-05-18 06:29:56'),
(43, '29.00', '57.00', '1984', '0', '0', '0', '62', '2022-05-18 06:30:05'),
(44, '29.00', '57.00', '2066', '0', '0', '0', '59', '2022-05-18 06:30:14'),
(45, '29.00', '57.00', '1987', '0', '0', '0', '62', '2022-05-18 06:30:23'),
(46, '29.00', '57.00', '1951', '0', '0', '0', '59', '2022-05-18 06:30:31'),
(47, '29.00', '57.00', '2001', '0', '0', '0', '61', '2022-05-18 06:30:41'),
(48, '29.00', '57.00', '1973', '0', '0', '0', '59', '2022-05-18 06:30:50'),
(49, '29.00', '57.00', '1990', '0', '0', '0', '62', '2022-05-18 06:30:59'),
(50, '29.00', '57.00', '1945', '0', '0', '0', '62', '2022-05-18 06:31:08'),
(51, '29.00', '57.00', '2001', '0', '0', '0', '68', '2022-05-18 06:31:17'),
(52, '29.00', '57.00', '2045', '0', '0', '0', '63', '2022-05-18 06:31:25'),
(53, '29.00', '57.00', '1968', '0', '0', '0', '62', '2022-05-18 06:31:34'),
(54, '29.40', '55.00', '1763', '0', '0', '0', '0', '2022-05-18 08:13:54'),
(55, '29.40', '55.00', '1740', '0', '0', '0', '0', '2022-05-18 08:14:03'),
(56, '29.40', '55.00', '1765', '0', '0', '0', '61', '2022-05-18 08:14:12'),
(57, '29.40', '55.00', '1763', '0', '0', '0', '61', '2022-05-18 08:14:21'),
(58, '29.50', '55.00', '1797', '0', '0', '0', '60', '2022-05-18 08:14:30'),
(59, '29.50', '55.00', '1741', '0', '0', '0', '60', '2022-05-18 08:14:39'),
(60, '29.50', '55.00', '1738', '0', '0', '0', '60', '2022-05-18 08:14:48'),
(61, '29.40', '55.00', '1722', '0', '0', '0', '64', '2022-05-18 08:14:57'),
(62, '29.50', '55.00', '1747', '0', '0', '0', '59', '2022-05-18 08:15:06'),
(63, '29.50', '55.00', '1765', '0', '0', '0', '59', '2022-05-18 08:15:15'),
(64, '29.50', '55.00', '1808', '0', '0', '0', '60', '2022-05-18 08:15:23'),
(65, '29.50', '55.00', '1814', '0', '0', '0', '59', '2022-05-18 08:15:34'),
(66, '29.50', '55.00', '1775', '0', '0', '0', '59', '2022-05-18 08:15:43'),
(67, '29.50', '55.00', '1779', '0', '0', '0', '0', '2022-05-18 08:15:52'),
(68, '29.50', '55.00', '1767', '0', '0', '0', '0', '2022-05-18 08:16:01'),
(69, '29.50', '54.00', '1781', '0', '0', '0', '0', '2022-05-18 08:16:10'),
(70, '29.50', '55.00', '1771', '0', '0', '0', '0', '2022-05-18 08:16:18'),
(71, '29.50', '54.00', '1744', '0', '0', '0', '0', '2022-05-18 08:16:28'),
(72, '29.50', '54.00', '1750', '0', '0', '0', '0', '2022-05-18 08:16:37'),
(73, '29.50', '54.00', '1738', '0', '0', '0', '0', '2022-05-18 08:16:51'),
(74, '29.50', '54.00', '1751', '0', '0', '0', '0', '2022-05-18 08:17:01'),
(75, '29.50', '54.00', '1753', '0', '0', '0', '0', '2022-05-18 08:17:15'),
(76, '29.50', '54.00', '1746', '0', '0', '0', '0', '2022-05-18 08:17:24'),
(77, '29.40', '54.00', '1777', '0', '0', '0', '0', '2022-05-18 08:17:33'),
(78, '29.40', '54.00', '1741', '0', '0', '0', '0', '2022-05-18 08:17:41'),
(79, '29.50', '54.00', '1727', '0', '0', '0', '0', '2022-05-18 08:17:50');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `id` int(11) NOT NULL,
  `server` text NOT NULL,
  `gsm` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`id`, `server`, `gsm`) VALUES
(1, 'on', 'off');

-- --------------------------------------------------------

--
-- Table structure for table `temp_humi`
--

CREATE TABLE `temp_humi` (
  `id` int(11) NOT NULL,
  `temperature` text NOT NULL,
  `humidity` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `temp_humi`
--

INSERT INTO `temp_humi` (`id`, `temperature`, `humidity`) VALUES
(1, '25', '90');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `boards`
--
ALTER TABLE `boards`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `device_1`
--
ALTER TABLE `device_1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `device_2`
--
ALTER TABLE `device_2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `device_3`
--
ALTER TABLE `device_3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `device_4`
--
ALTER TABLE `device_4`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `outputs`
--
ALTER TABLE `outputs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `powerusage`
--
ALTER TABLE `powerusage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sensordata`
--
ALTER TABLE `sensordata`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `temp_humi`
--
ALTER TABLE `temp_humi`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `boards`
--
ALTER TABLE `boards`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `outputs`
--
ALTER TABLE `outputs`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `powerusage`
--
ALTER TABLE `powerusage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sensordata`
--
ALTER TABLE `sensordata`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
