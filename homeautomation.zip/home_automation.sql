-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 16, 2022 at 11:17 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `home_automation`
--

-- --------------------------------------------------------

--
-- Table structure for table `device_1`
--

CREATE TABLE `device_1` (
  `id` int(11) NOT NULL,
  `status` text NOT NULL,
  `light_intensity` text NOT NULL,
  `power` text NOT NULL,
  `auto` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `device_1`
--

INSERT INTO `device_1` (`id`, `status`, `light_intensity`, `power`, `auto`) VALUES
(1, 'on', '37', '200', 'off');

-- --------------------------------------------------------

--
-- Table structure for table `device_2`
--

CREATE TABLE `device_2` (
  `id` int(11) NOT NULL,
  `status` text NOT NULL,
  `fan_speed` text NOT NULL,
  `power` text NOT NULL,
  `auto` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `device_2`
--

INSERT INTO `device_2` (`id`, `status`, `fan_speed`, `power`, `auto`) VALUES
(1, 'on', '99', '100', 'off');

-- --------------------------------------------------------

--
-- Table structure for table `device_3`
--

CREATE TABLE `device_3` (
  `id` int(11) NOT NULL,
  `status` text NOT NULL,
  `power` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `device_3`
--

INSERT INTO `device_3` (`id`, `status`, `power`) VALUES
(1, 'on', '200');

-- --------------------------------------------------------

--
-- Table structure for table `device_4`
--

CREATE TABLE `device_4` (
  `id` int(11) NOT NULL,
  `status` text NOT NULL,
  `power` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `device_4`
--

INSERT INTO `device_4` (`id`, `status`, `power`) VALUES
(1, 'on', '200');

-- --------------------------------------------------------

--
-- Table structure for table `powerusage`
--

CREATE TABLE `powerusage` (
  `id` int(11) NOT NULL,
  `device` text NOT NULL,
  `date` text NOT NULL,
  `power` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `id` int(11) NOT NULL,
  `server` text NOT NULL,
  `gsm` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`id`, `server`, `gsm`) VALUES
(1, 'on', 'off');

-- --------------------------------------------------------

--
-- Table structure for table `temp_humi`
--

CREATE TABLE `temp_humi` (
  `id` int(11) NOT NULL,
  `temperature` text NOT NULL,
  `humidity` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `temp_humi`
--

INSERT INTO `temp_humi` (`id`, `temperature`, `humidity`) VALUES
(1, '25', '90');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `device_1`
--
ALTER TABLE `device_1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `device_2`
--
ALTER TABLE `device_2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `device_3`
--
ALTER TABLE `device_3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `device_4`
--
ALTER TABLE `device_4`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `powerusage`
--
ALTER TABLE `powerusage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `temp_humi`
--
ALTER TABLE `temp_humi`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `powerusage`
--
ALTER TABLE `powerusage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
