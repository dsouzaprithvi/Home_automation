<!DOCTYPE html>
<html><body>
<?php
/*
  Rui Santos
  Complete project details at https://RandomNerdTutorials.com/esp32-esp8266-mysql-database-php/
  
  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files.
  
  The above copyright notice and this permission notice shall be included in all
  copies or substantial portions of the Software.
*/

$servername = "localhost";

// REPLACE with your Database name
$dbname = "home_automation";
// REPLACE with Database user
$username = "root";
// REPLACE with Database user password
$password = "";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT id, TemperatureValue, HumidityValue, LightSensorValue, Relay_1_Power_Value, Relay_2_Power_Value, Bulb_Power_Value, Fan_Power_Value, reading_time FROM SensorData ORDER BY id DESC";

echo '<table cellspacing="5" cellpadding="5">
      <tr> 
        <td>ID</td>
        <td>TemperatureValue</td> 
        <td>HumidityValue</td>
        <td>LightSensorValue</td>
	<td>Relay_1_Power_Value</td>
	<td>Relay_2_Power_Value</td>
	<td>Bulb_Power_Value</td>
	<td>Fan_Power_Value</td> 
        <td>Timestamp</td> 
      </tr>';
 
if ($result = $conn->query($sql)) {
    while ($row = $result->fetch_assoc()) {
        $row_id = $row["id"];
        $row_TemperatureValue = $row["TemperatureValue"];
        $row_HumidityValue = $row["HumidityValue"]; 
        $row_LightSensorValue = $row["LightSensorValue"];
	$row_Relay_1_Power_Value = $row["Relay_1_Power_Value"];
	$row_Relay_2_Power_Value = $row["Relay_2_Power_Value"];
	$row_Bulb_Power_Value = $row["Bulb_Power_Value"];
	$row_Fan_Power_Value = $row["Fan_Power_Value"]; 
        $row_reading_time = $row["reading_time"];
        // Uncomment to set timezone to - 1 hour (you can change 1 to any number)
        //$row_reading_time = date("Y-m-d H:i:s", strtotime("$row_reading_time - 1 hours"));
      
        // Uncomment to set timezone to + 4 hours (you can change 4 to any number)
        //$row_reading_time = date("Y-m-d H:i:s", strtotime("$row_reading_time + 4 hours"));
      
        echo '<tr> 
                <td>' . $row_id . '</td> 
                <td>' . $row_TemperatureValue . '</td> 
                <td>' . $row_HumidityValue . '</td>
                <td>' . $row_LightSensorValue . '</td>
                <td>' . $row_Relay_1_Power_Value . '</td>
                <td>' . $row_Relay_2_Power_Value . '</td>
                <td>' . $row_Bulb_Power_Value . '</td>
                <td>' . $row_Fan_Power_Value . '</td> 
                <td>' . $row_reading_time . '</td> 
              </tr>';
    }
    $result->free();
}

$conn->close();
?> 
</table>
</body>
</html>