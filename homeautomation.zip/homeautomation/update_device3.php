<?php
$conn = mysqli_connect("localhost","root","");
mysqli_select_db($conn,"home_automation");


$status = trim($_POST['status']);
$power = trim($_POST['power']);


$qry = "UPDATE `device_3` SET `id`='1',`status`='$status' WHERE `id` = '1'";
		$res = mysqli_query($conn, $qry);
		if($res == true)
			$response['message'] = "updated";
		else
			$response['message'] = "failed";
		
echo json_encode($response);

?>