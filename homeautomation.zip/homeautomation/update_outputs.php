<?php
$conn = mysqli_connect("localhost","root","");
mysqli_select_db($conn,"home_automation");



$name = trim($_POST['name']);
$state = trim($_POST['state']);

$qry = "UPDATE `outputs` SET `state`='$state' WHERE `name` = '$name'";
		$res = mysqli_query($conn, $qry);
		if($res == true)
			$response['message'] = "updated";
		else
			$response['message'] = "failed";
		
echo json_encode($response);

?>