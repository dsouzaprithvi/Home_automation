<?php
$conn = mysqli_connect("localhost","root","");
mysqli_select_db($conn,"home_automation");



$qry = "select * from temp_humi where id = '1'";

$raw = mysqli_query($conn,$qry);

$count = mysqli_num_rows($raw);

if($count > 0){
	while($res = mysqli_fetch_array($raw)){
		$data[] = $res;
		}
}
else{
	$data[] = NULL;
}

echo json_encode($data);
?>