<?php

$servername = "localhost";

// REPLACE with your Database name
$dbname = "home_automation";
// REPLACE with Database user
$username = "root";
// REPLACE with Database user password
$password = "";

// Keep this API Key value to be compatible with the ESP32 code provided in the project page. 
// If you change this value, the ESP32 sketch needs to match
$api_key_value = "tPmAT5Ab3j7F9";

$api_key= $TemperatureValue = $HumidityValue = $LightSensorValue = $Relay_1_Power_Value = $Relay_2_Power_Value = $Bulb_Power_Value = $Fan_Power_Value = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $api_key = test_input($_POST["api_key"]);
    if($api_key == $api_key_value) {
        $TemperatureValue = test_input($_POST["TemperatureValue"]);
        $HumidityValue = test_input($_POST["HumidityValue"]);
        $LightSensorValue = test_input($_POST["LightSensorValue"]);
	$Relay_1_Power_Value = test_input($_POST["Relay_1_Power_Value"]);
	$Relay_2_Power_Value = test_input($_POST["Relay_2_Power_Value"]);
	$Bulb_Power_Value = test_input($_POST["Bulb_Power_Value"]);
	$Fan_Power_Value = test_input($_POST["Fan_Power_Value"]);
        
        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } 
        
        $sql = "INSERT INTO SensorData (TemperatureValue, HumidityValue, LightSensorValue, Relay_1_Power_Value, Relay_2_Power_Value, Bulb_Power_Value, Fan_Power_Value)
        VALUES ('" . $TemperatureValue . "', '" . $HumidityValue . "', '" . $LightSensorValue . "', '" . $Relay_1_Power_Value . "', '" . $Relay_2_Power_Value . "', '" . $Bulb_Power_Value . "', '" . $Fan_Power_Value . "')";
        
        if ($conn->query($sql) === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    
        $conn->close();
    }
    else {
        echo "Wrong API Key provided.";
    }

}
else {
    echo "No data posted with HTTP POST.";
}

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}