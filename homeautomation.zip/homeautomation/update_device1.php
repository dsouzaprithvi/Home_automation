<?php
$conn = mysqli_connect("localhost","root","");
mysqli_select_db($conn,"home_automation");


$status = trim($_POST['status']);
$light_intensity = trim($_POST['light_intensity']);
$power = trim($_POST['power']);
$auto = trim($_POST['auto']);

$qry = "UPDATE `device_1` SET `id`='1',`status`='$status',`light_intensity`='$light_intensity',`auto`='$auto' WHERE `id` = '1'";
		$res = mysqli_query($conn, $qry);
		if($res == true)
			$response['message'] = "updated";
		else
			$response['message'] = "failed";
		
echo json_encode($response);

?>